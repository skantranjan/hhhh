import { useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { useApiWithTokenRefresh } from './useApiWithTokenRefresh';

interface RoleCheckerConfig {
  checkInterval: number; // in milliseconds
  enabled: boolean;
}

const DEFAULT_CONFIG: RoleCheckerConfig = {
  checkInterval: 30000, // Check every 30 seconds
  enabled: true
};

export const useRoleChecker = (config: RoleCheckerConfig = DEFAULT_CONFIG) => {
  const { user, isAuthenticated, login } = useAuth();
  const navigate = useNavigate();
  const { apiPostWithRefresh } = useApiWithTokenRefresh();
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const lastCheckRef = useRef<number>(0);
  const configRef = useRef<RoleCheckerConfig>(config);

  const checkRoleChange = async () => {
    if (!isAuthenticated || !user || !user.email) {
      return;
    }

    try {
     
      
      // Call API to get current user data
      const response = await apiPostWithRefresh(
        '/user',
        { email: user.email },
        'application/json'
      );

      if (response.success && response.data) {
        const currentUserData = response.data;
        const currentRole = currentUserData.role;
        const storedRole = localStorage.getItem('lastKnownRole');
        
      
        // Check if role has changed
        if (storedRole && storedRole !== currentRole.toString()) {
        
          // Update user data in context
          login(currentUserData);
          
          // Update stored role
          localStorage.setItem('lastKnownRole', currentRole.toString());
          
          // Show alert to user - REMOVED as requested
          // alert(`Your role has been updated!\n\nNew Role: ${currentRole}\n\nYou will be redirected to the appropriate page.`);
          
          // Redirect to landing page to trigger role-based routing
          navigate('/landing', { replace: true });
          return;
        }
        
        // Update stored role if it matches (in case of other data changes)
        localStorage.setItem('lastKnownRole', currentRole.toString());
        
        // Update user data in context (in case other user data changed)
        if (JSON.stringify(user) !== JSON.stringify(currentUserData)) {
          console.log('🔍 Role Checker: User data updated (non-role changes)');
          login(currentUserData);
        }
        
      } else {
        console.warn('🔍 Role Checker: Failed to get user data from API');
      }
      
    } catch (error) {
      console.error('🔍 Role Checker: Error checking role:', error);
    }
  };

  // Update config ref when config changes
  useEffect(() => {
    configRef.current = config;
  }, [config]);

  useEffect(() => {
    if (!configRef.current.enabled || !isAuthenticated || !user) {
      return;
    }

    // Initial check after a short delay
    const initialTimer = setTimeout(() => {
      checkRoleChange();
      lastCheckRef.current = Date.now();
    }, 5000); // Wait 5 seconds after authentication

    // Set up interval for periodic checks
    intervalRef.current = setInterval(() => {
      const now = Date.now();
      const timeSinceLastCheck = now - lastCheckRef.current;
      
      // Only check if enough time has passed
      if (timeSinceLastCheck >= configRef.current.checkInterval) {
        checkRoleChange();
        lastCheckRef.current = now;
      }
    }, configRef.current.checkInterval);

    return () => {
      clearTimeout(initialTimer);
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isAuthenticated, user]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  return {
    checkRoleChange,
    isChecking: false
  };
};
