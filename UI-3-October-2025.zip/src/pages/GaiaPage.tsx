import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate, useLocation } from 'react-router-dom';
import Layout from '../components/Layout';
import MultiSelect from '../components/MultiSelect';
import { apiGet } from '../utils/api';

// Master Data Response Interface
interface MasterDataResponse {
  success: boolean;
  message: string;
  data: {
    periods?: Array<{id: number, period: string, is_active: boolean}>;
    material_types?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    component_packaging_type?: Array<{id: number, item_name: string, item_name_new?: string}>;
  };
}

const GaiaPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();
  
  // Data will be loaded from API instead of passed from AdminCmSkuDetail page
  const [cmCode, setCmCode] = useState<string>('');
  const [cmDescription, setCmDescription] = useState<string>('');
  const [tableData, setTableData] = useState<any[]>([]);
  const [originalTableData, setOriginalTableData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [materialTypes, setMaterialTypes] = useState<Array<{id: number, item_name: string}>>([]);
  
  
  // Master data state
  const [periods, setPeriods] = useState<Array<{id: number, period: string, is_active: boolean}>>([]);
  const [currentPeriod, setCurrentPeriod] = useState<string>('');
  const [selectedComponentTypes, setSelectedComponentTypes] = useState<string[]>([]);
  const [selectedComponentPackagingTypes, setSelectedComponentPackagingTypes] = useState<string[]>([]);
  const [excludeInternal, setExcludeInternal] = useState<boolean>(true);
  const [appliedExcludeInternal, setAppliedExcludeInternal] = useState<boolean>(true);
  const [appliedPeriod, setAppliedPeriod] = useState<string>('');
  const [appliedComponentTypes, setAppliedComponentTypes] = useState<string[]>([]);
  const [appliedComponentPackagingTypes, setAppliedComponentPackagingTypes] = useState<string[]>([]);
  const [componentPackagingTypes, setComponentPackagingTypes] = useState<Array<{id: number, item_name: string, item_name_new?: string}>>([]);
  const [hasLoadedInitialData, setHasLoadedInitialData] = useState<boolean>(false);

  // Load initial data on component mount
  useEffect(() => {
    loadInitialData();
  }, []);

  // Load component data when CMO code and applied filters are ready (only once)
  useEffect(() => {
    if (cmCode && appliedPeriod && appliedComponentTypes.length > 0 && !hasLoadedInitialData) {
      setHasLoadedInitialData(true);
      loadComponentData();
    }
  }, [cmCode, appliedPeriod, appliedComponentTypes, hasLoadedInitialData]);

  // Load master data
  const loadMasterData = async () => {
    try {
      const response = await apiGet('/masterdata');
      
      if (response.success && response.data) {
        setPeriods(response.data.periods || []);
        setMaterialTypes(response.data.material_types || []);
        
        if (response.data.component_packaging_type) {
          const packagingTypes = response.data.component_packaging_type.map((type: any) => ({
            id: type.id,
            item_name: type.item_name,
            item_name_new: type.item_name_new
          }));
          setComponentPackagingTypes(packagingTypes);
        }
        
        // Set current period to the highest active period
        const activePeriods = (response.data.periods || []).filter((p: any) => p.is_active);
        let periodId = '';
        if (activePeriods.length > 0) {
          const highestPeriod = activePeriods.reduce((max: any, current: any) => 
            current.id > max.id ? current : max
          );
          periodId = highestPeriod.id.toString();
          setCurrentPeriod(periodId);
        }
        
        // Set default component types from master data (first material type)
        let defaultComponentTypes: string[] = [];
        if (response.data.material_types && response.data.material_types.length > 0) {
          defaultComponentTypes = [response.data.material_types[0].item_name];
          setSelectedComponentTypes(defaultComponentTypes);
        }
        
        // Initialize applied filter states with current values
        setAppliedPeriod(periodId);
        setAppliedComponentTypes(defaultComponentTypes);
        setAppliedComponentPackagingTypes([]);
        setAppliedExcludeInternal(true);
        
        setError(null);
      } else {
        setError(`Failed to load master data: ${response.message || 'Unknown error'}`);
      }
    } catch (error: any) {
      setError(`Error loading master data: ${error.message || 'Network or server error'}`);
    }
  };

  // Load initial data
  const loadInitialData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Load master data first
      await loadMasterData();
      
      // Get parameters from URL
      const cmCodeParam = searchParams.get('cmCode');
      const cmDescriptionParam = searchParams.get('cmDescription');
      
      if (cmCodeParam) {
        setCmCode(cmCodeParam);
      }
      
      if (cmDescriptionParam) {
        setCmDescription(cmDescriptionParam);
      }

      // Get data from location state if available
      const locationState = location.state;
      if (locationState?.skuData) {
        setTableData(locationState.skuData);
      }
      
    } catch (error) {
      setError('Error loading initial data');
    } finally {
      setLoading(false);
    }
  };



  // Load component data based on current filters
  const loadComponentData = async () => {
    if (!cmCode) {
      return;
    }

    try {
      const params = new URLSearchParams({
        cm_code: cmCode,
        period_id: appliedPeriod || currentPeriod
      });
      
      const response = await apiGet(`/components/filterdata-generatepdf?${params.toString()}`);
      
      if (response.success) {
        const transformedData = transformApiResponse(response.data);
        setOriginalTableData(response.data); // Store original API data
        
        // Apply bulk_expert filter immediately after transformation
        const filteredData = transformedData.filter(row => {
          const bulkExpert = row.bulk_expert?.toLowerCase();
          return !(bulkExpert === 'bulk' || bulkExpert === 'expert');
        });
        
        setTableData(filteredData);
        setError(null);
      } else {
        setError(`Failed to load component data: ${response.message || 'Unknown error'}`);
      }
    } catch (error: any) {
      setError(`Error loading component data: ${error.message || 'Network or server error'}`);
    }
  };

  // Transform API response to table format
  const transformApiResponse = (data: any) => {
    if (!data || !Array.isArray(data)) return [];
    
    return data.map((item: any, index: number) => ({
      id: index,
      // CM Code & Description
      cm_code: item.sku_cm_code || item.mapping_cm_code || '',
      cm_description: item.cm_description || '',
      
      // SKU Information
      sku_code: item.sku_code || '',
      sku_description: item.sku_description || '',
      purchased_quantity: '', // Not in API response
      reference_sku: item.sku_reference || '',
      sku_reference_check: '', // Not in API response
      formulation_reference: item.formulation_reference || '',
      
      // Material Type
      material_type: item.material_type_id || '',
      
      // Bulk Expert (for filtering)
      bulk_expert: item.bulk_expert || '',
      
      // Components Reference
      components_reference: item.components_reference || '',
      
      // Component Information
      component_code: item.component_code || '',
      component_description: item.component_description || '',
      component_validity_from: item.component_valid_from || '',
      component_validity_to: item.component_valid_to || '',
      component_material_group: item.component_material_group || '',
      component_quantity: item.component_quantity || '',
      component_unit_of_measure: item.component_uom_id || '',
      component_base_quantity: item.component_base_quantity || '',
      component_base_unit_of_measure: item.component_base_uom_id || '',
      component_percent_w_w: item.percent_w_w || '',
      
      // Evidence
      evidence: '', // Not in API response
      
      // Packaging Information
      component_packaging_type: item.component_packaging_type_id || item.mapping_packaging_type || '',
      component_packaging_material: item['Component Packaging Material'] || '',
      helper_column: '', // Not in API response
      component_unit_weight: item.component_unit_weight || '',
      weight_unit_measure: item.weight_unit_measure_id || '',
      
      // Recycled Content
      percent_mechanical_pcr_content: item.percent_mechanical_pcr_content || '',
      percent_mechanical_pir_content: item.percent_mechanical_pir_content || '',
      percent_chemical_recycled_content: item.percent_chemical_recycled_content || '',
      percent_bio_sourced: item.percent_bio_sourced || '',
      
      // Material Structure
      material_structure_multimaterial: '', // Not in API response
      
      // Packaging Details
      component_packaging_colour: '', // Not in API response
      component_packaging_level: item.component_packaging_level_id || '',
      component_dimensions: item.component_dimensions || '',
      
      // Evidence
      packaging_specification_evidence: '', // Not in API response
      evidence_of_recycled_or_bio_source: item.evidence_of_recycled_or_bio_source || '',
      
      // Last Update
      last_update_date: (() => {
        const dateValue = item.component_created_date || item.mapping_created_at;
        if (dateValue) {
          const date = new Date(dateValue);
          return date.toLocaleDateString('en-GB', {
            day: '2-digit',
            month: '2-digit',
            year: '2-digit'
          });
        }
        return '';
      })()
    }));
  };



  // Handle apply filters button click
  const handleApplyFilters = () => {
    setAppliedPeriod(currentPeriod);
    setAppliedComponentTypes([...selectedComponentTypes]);
    setAppliedComponentPackagingTypes([...selectedComponentPackagingTypes]);
    setAppliedExcludeInternal(excludeInternal);
    
    applyClientSideFilters();
  };

  // Apply client-side filtering to the data
  const applyClientSideFilters = () => {
    // Get the original data from the API response (before any filtering)
    const originalData = transformApiResponse(originalTableData || []);
    let filteredData = [...originalData];
    
    console.log('🔍 Applying filters with:', {
      appliedComponentTypes,
      appliedComponentPackagingTypes,
      appliedExcludeInternal,
      originalDataCount: originalData.length
    });
    
    // First, exclude records with bulk_expert values of "bulk" or "expert"
    // (This is also applied at data load time, but we apply it here too for consistency)
    filteredData = filteredData.filter(row => {
      const bulkExpert = row.bulk_expert?.toLowerCase();
      const shouldExclude = bulkExpert === 'bulk' || bulkExpert === 'expert';
      console.log('Bulk Expert filter:', { 
        bulkExpert: row.bulk_expert,
        shouldExclude
      });
      return !shouldExclude;
    });
    console.log('After Bulk Expert filter:', filteredData.length);
    
    // Apply Component Types filter
    if (appliedComponentTypes.length > 0) {
      filteredData = filteredData.filter(row => {
        const matches = appliedComponentTypes.some(selectedType => 
          row.material_type === selectedType
        );
        console.log('Component Type filter:', { 
          rowMaterialType: row.material_type, 
          selectedTypes: appliedComponentTypes, 
          matches 
        });
        return matches;
      });
      console.log('After Component Types filter:', filteredData.length);
    }
    
    // Apply Component Packaging Types filter
    if (appliedComponentPackagingTypes.length > 0) {
      filteredData = filteredData.filter(row => {
        const matches = appliedComponentPackagingTypes.some(selectedType => 
          row.component_packaging_type === selectedType
        );
        console.log('Packaging Type filter:', { 
          rowPackagingType: row.component_packaging_type, 
          selectedTypes: appliedComponentPackagingTypes, 
          matches 
        });
        return matches;
      });
      console.log('After Packaging Types filter:', filteredData.length);
    }
    
    // Apply Exclude Internal filter
    if (appliedExcludeInternal) {
      filteredData = filteredData.filter(row => {
        // Check if the row contains any internal indicators
        const isInternal = row.material_type?.toLowerCase().includes('internal') ||
                          row.component_description?.toLowerCase().includes('internal') ||
                          row.component_code?.toLowerCase().includes('internal');
        console.log('Exclude Internal filter:', { 
          rowMaterialType: row.material_type,
          isInternal,
          shouldExclude: !isInternal
        });
        return !isInternal;
      });
      console.log('After Exclude Internal filter:', filteredData.length);
    }
    
    console.log('Final filtered data count:', filteredData.length);
    setTableData(filteredData);
  };

  // Handle reset filters button click
  const handleResetFilters = () => {
    setSelectedComponentTypes([]);
    setSelectedComponentPackagingTypes([]);
    setExcludeInternal(true);
    
    setAppliedPeriod(currentPeriod);
    setAppliedComponentTypes([]);
    setAppliedComponentPackagingTypes([]);
    setAppliedExcludeInternal(true);
    
    // Reset to show all original data
    if (originalTableData.length > 0) {
      const transformedData = transformApiResponse(originalTableData);
      setTableData(transformedData);
    }
  };

  // Handle export to Excel
  const handleExportToExcel = () => {
    if (tableData.length === 0) {
      alert('No data to export');
      return;
    }

    // Create CSV content
    const headers = [
      'CM Code', 'CM Description', 'SKU Code', 'SKU Description', 'Purchased Quantity',
      'Reference SKU', 'SKU Reference Check', 'Formulation Reference', 'Material Type',
      'Components Reference', 'Component Code', 'Component Description', 'Component Validity From',
      'Component Validity To', 'Component Material Group', 'Component Quantity',
      'Component Unit of Measure', 'Component Base Quantity', 'Component Base Unit of Measure',
      'Component %w/w', 'Evidence', 'Component Packaging Type', 'Component Packaging Material',
      'Helper Column', 'Component Unit Weight', 'Weight Unit Measure',
      '% Mechanical Post-Consumer Recycled Content(inc Chemical)',
      '% Mechanical Post-Industrial Recycled Content', '% Chemical Recycled Content',
      '% Bio Sourced', 'Material Structure-multimaterial only(with % wt)',
      'Component Packaging Colour', 'Component Packaging Level', 'Component Dimensions',
      'Packaging Specification Evidence', 'Evidence of Recycled or Bio Source', 'Last Update Date'
    ];

    // Convert data to CSV format
    const csvContent = [
      headers.join(','),
      ...tableData.map(row => [
        `"${row.cm_code || ''}"`,
        `"${row.cm_description || ''}"`,
        `"${row.sku_code || ''}"`,
        `"${row.sku_description || ''}"`,
        `"${row.purchased_quantity || ''}"`,
        `"${row.reference_sku || ''}"`,
        `"${row.sku_reference_check || ''}"`,
        `"${row.formulation_reference || ''}"`,
        `"${row.material_type || ''}"`,
        `"${row.components_reference || ''}"`,
        `"${row.component_code || ''}"`,
        `"${row.component_description || ''}"`,
        `"${row.component_validity_from || ''}"`,
        `"${row.component_validity_to || ''}"`,
        `"${row.component_material_group || ''}"`,
        `"${row.component_quantity || ''}"`,
        `"${row.component_unit_of_measure || ''}"`,
        `"${row.component_base_quantity || ''}"`,
        `"${row.component_base_unit_of_measure || ''}"`,
        `"${row.component_percent_w_w || ''}"`,
        `"${row.evidence || ''}"`,
        `"${row.component_packaging_type || ''}"`,
        `"${row.component_packaging_material || ''}"`,
        `"${row.helper_column || ''}"`,
        `"${row.component_unit_weight || ''}"`,
        `"${row.weight_unit_measure || ''}"`,
        `"${row.percent_mechanical_pcr_content || ''}"`,
        `"${row.percent_mechanical_pir_content || ''}"`,
        `"${row.percent_chemical_recycled_content || ''}"`,
        `"${row.percent_bio_sourced || ''}"`,
        `"${row.material_structure_multimaterial || ''}"`,
        `"${row.component_packaging_colour || ''}"`,
        `"${row.component_packaging_level || ''}"`,
        `"${row.component_dimensions || ''}"`,
        `"${row.packaging_specification_evidence || ''}"`,
        `"${row.evidence_of_recycled_or_bio_source || ''}"`,
        `"${row.last_update_date || ''}"`
      ].join(','))
    ].join('\n');

    // Create and download file
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    
    // Generate filename with timestamp
    const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    const filename = `GAIA_Export_${cmCode}_${timestamp}.csv`;
    link.setAttribute('download', filename);
    
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };


  return (
    <Layout>
      <div className="mainInternalPages">
        <div style={{ marginBottom: 8 }}>
        </div>
        {/* Dashboard Header */}
        <div className="commonTitle" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <div className="icon">
              <i className="ri-global-line"></i>
            </div>
            <h1>GAIA</h1>
          </div>
          <button
            onClick={() => navigate(-1)}
            style={{
              background: '#30ea03',
              color: '#000',
              border: 'none',
              borderRadius: '4px',
              padding: '10px 20px',
              fontWeight: 'bold',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '14px',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
              transition: 'all 0.2s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = '#28c003';
              e.currentTarget.style.transform = 'translateY(-1px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = '#30ea03';
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            <i className="ri-arrow-left-line"></i>
            Back
          </button>
        </div>

        {/* CMO Info Section */}
        <div className="filters CMDetails">
          <div className="row">
            <div className="col-sm-12">
              <ul style={{ display: 'flex', alignItems: 'center', padding: '6px 15px 8px' }}>
                <li><strong>CMO Code: </strong> {cmCode}</li>
                <li> | </li>
                <li><strong>CMO Description: </strong> {cmDescription}</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Professional Error Display Section */}
        {error && (
              <div style={{
            background: 'linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%)',
            border: '1px solid #fecaca',
            borderRadius: '12px',
            padding: '20px 24px',
            marginBottom: '24px',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            boxShadow: '0 2px 12px rgba(239, 68, 68, 0.1)'
          }}>
            <div style={{
              background: '#ef4444',
              borderRadius: '8px',
              padding: '8px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0
            }}>
              <i className="ri-error-warning-line" style={{ fontSize: '18px', color: '#fff' }}></i>
            </div>
            <div>
              <div style={{ 
                fontSize: '14px', 
                fontWeight: '100', 
                color: '#dc2626',
                marginBottom: '4px'
              }}>
                Error Loading Data
              </div>
              <div style={{ 
                fontSize: '14px', 
                color: '#991b1b',
                lineHeight: '1.5'
              }}>
                {error}
              </div>
            </div>
          </div>
        )}

        {/* Professional Filters Section - Reference Design */}
        <div className="row"> 
          <div className="col-sm-12">
            <div className="filters" style={{
              backgroundColor: '#fff',
              borderRadius: '8px',
              padding: '20px',
              marginBottom: '20px',
              border: '1px solid #e9ecef',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)'
            }}>
              {/* Professional Filter Row */}
              <div style={{ 
                display: 'flex', 
                gap: '20px', 
                alignItems: 'end',
                flexWrap: 'wrap',
                marginBottom: '20px',
                padding: '20px',
                backgroundColor: '#f8f9fa',
                borderRadius: '8px',
                border: '1px solid #e9ecef'
              }}>
                {/* Period Filter */}
                <div style={{ minWidth: '160px' }}>
                  <label style={{ 
                    display: 'block', 
                    marginBottom: '6px', 
                    fontSize: '13px', 
                    fontWeight: '600', 
                    color: '#495057' 
                  }}>
                    Period
                  </label>
                  <select
                    value={currentPeriod}
                    disabled={true}
                    style={{
                      width: '100%',
                      padding: '10px 12px',
                      borderRadius: '6px',
                      fontSize: '13px',
                      backgroundColor: '#ffffff',
                      border: '2px solid #e9ecef',
                      outline: 'none',
                      color: '#6c757d',
                      cursor: 'not-allowed',
                      height: '40px',
                      boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                      transition: 'all 0.2s ease'
                    }}
                  >
                    <option value={currentPeriod}>
                      {periods.find(p => p.id.toString() === currentPeriod)?.period || 'Loading...'}
                    </option>
                  </select>
                </div>

                {/* Component Types Filter */}
                <div style={{ minWidth: '180px' }}>
                  <label style={{ 
                    display: 'block', 
                    marginBottom: '6px', 
                    fontSize: '13px', 
                    fontWeight: '600', 
                    color: '#495057' 
                  }}>
                    Component Types
                  </label>
                  <div style={{
                    border: '2px solid #e9ecef',
                    borderRadius: '6px',
                    backgroundColor: '#ffffff',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                    minHeight: '40px'
                  }}>
                    <MultiSelect
                      options={materialTypes.map(type => ({
                        value: type.item_name,
                        label: type.item_name
                      }))}
                      selectedValues={selectedComponentTypes}
                      onSelectionChange={setSelectedComponentTypes}
                      placeholder="Select component types..."
                    />
                  </div>
                </div>

                {/* Packaging Types Filter */}
                <div style={{ minWidth: '180px' }}>
                  <label style={{ 
                    display: 'block', 
                    marginBottom: '6px', 
                    fontSize: '13px', 
                    fontWeight: '600', 
                    color: '#495057' 
                  }}>
                    Packaging Types
                  </label>
                  <div style={{
                    border: '2px solid #e9ecef',
                    borderRadius: '6px',
                    backgroundColor: '#ffffff',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                    minHeight: '40px'
                  }}>
                    <MultiSelect
                      options={componentPackagingTypes
                        .filter(type => type.item_name_new)
                        .map(type => ({
                          value: type.item_name_new!,
                          label: type.item_name_new!
                        }))}
                      selectedValues={selectedComponentPackagingTypes}
                      onSelectionChange={setSelectedComponentPackagingTypes}
                      placeholder="Select packaging types..."
                    />
                  </div>
                </div>

                {/* Exclude Internal Checkbox */}
                <div style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: '8px', 
                  marginTop: '26px',
                  padding: '8px 12px',
                  backgroundColor: '#ffffff',
                  borderRadius: '6px',
                  border: '2px solid #e9ecef',
                  boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
                  minHeight: '40px'
                }}>
                  <input
                    type="checkbox"
                    id="excludeInternal"
                    checked={excludeInternal}
                    onChange={(e) => setExcludeInternal(e.target.checked)}
                    style={{ 
                      width: '16px', 
                      height: '16px',
                      accentColor: '#30ea03',
                      cursor: 'pointer'
                    }}
                  />
                  <label 
                    htmlFor="excludeInternal"
                    style={{ 
                      fontSize: '13px', 
                      color: '#495057',
                      fontWeight: '600',
                      cursor: 'pointer',
                      margin: 0
                    }}
                  >
                    Exclude Internal
                  </label>
                </div>

                {/* Action Buttons */}
                <div style={{ 
                  display: 'flex', 
                  gap: '12px', 
                  alignItems: 'center',
                  marginLeft: 'auto',
                  marginTop: '26px',
                  position: 'relative',
                  height: '40px',
                  minHeight: '40px'
                }}>
                  <button
                    style={{
                      backgroundColor: '#30ea03',
                      color: '#000',
                      border: 'none',
                      borderRadius: '6px',
                      padding: '10px 20px',
                      fontSize: '13px',
                      fontWeight: '600',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '6px',
                      transition: 'background-color 0.2s ease, box-shadow 0.2s ease',
                      height: '40px',
                      minHeight: '40px',
                      maxHeight: '40px',
                      boxShadow: '0 2px 4px rgba(48, 234, 3, 0.3)',
                      outline: 'none',
                      position: 'relative',
                      flexShrink: 0,
                      userSelect: 'none',
                      verticalAlign: 'top',
                      lineHeight: '1'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#28c003';
                      e.currentTarget.style.boxShadow = '0 4px 8px rgba(48, 234, 3, 0.4)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = '#30ea03';
                      e.currentTarget.style.boxShadow = '0 2px 4px rgba(48, 234, 3, 0.3)';
                    }}
                    onMouseDown={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      e.currentTarget.style.boxShadow = '0 1px 2px rgba(48, 234, 3, 0.3)';
                      e.currentTarget.style.transform = 'none';
                      e.currentTarget.style.position = 'relative';
                      e.currentTarget.style.top = '0';
                      e.currentTarget.style.left = '0';
                    }}
                    onMouseUp={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      e.currentTarget.style.boxShadow = '0 2px 4px rgba(48, 234, 3, 0.3)';
                      e.currentTarget.style.transform = 'none';
                      e.currentTarget.style.top = '0';
                      e.currentTarget.style.left = '0';
                    }}
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      e.currentTarget.style.transform = 'none';
                      e.currentTarget.style.top = '0';
                      e.currentTarget.style.left = '0';
                      handleApplyFilters();
                    }}
                  >
                    <i className="ri-search-line" style={{ fontSize: '14px' }}></i>
                    Apply Filters
                  </button>
                  <button
                    style={{
                      backgroundColor: '#30ea03',
                      color: '#000',
                      border: 'none',
                      borderRadius: '6px',
                      padding: '10px 20px',
                      fontSize: '13px',
                      fontWeight: '600',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '6px',
                      transition: 'background-color 0.2s ease, box-shadow 0.2s ease',
                      height: '40px',
                      minHeight: '40px',
                      maxHeight: '40px',
                      boxShadow: '0 2px 4px rgba(48, 234, 3, 0.3)',
                      outline: 'none',
                      position: 'relative',
                      flexShrink: 0,
                      userSelect: 'none',
                      verticalAlign: 'top',
                      lineHeight: '1'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#28c003';
                      e.currentTarget.style.boxShadow = '0 4px 8px rgba(48, 234, 3, 0.4)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = '#30ea03';
                      e.currentTarget.style.boxShadow = '0 2px 4px rgba(48, 234, 3, 0.3)';
                    }}
                    onMouseDown={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      e.currentTarget.style.boxShadow = '0 1px 2px rgba(48, 234, 3, 0.3)';
                      e.currentTarget.style.transform = 'none';
                      e.currentTarget.style.position = 'relative';
                      e.currentTarget.style.top = '0';
                      e.currentTarget.style.left = '0';
                    }}
                    onMouseUp={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      e.currentTarget.style.boxShadow = '0 2px 4px rgba(48, 234, 3, 0.3)';
                      e.currentTarget.style.transform = 'none';
                      e.currentTarget.style.top = '0';
                      e.currentTarget.style.left = '0';
                    }}
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      e.currentTarget.style.transform = 'none';
                      e.currentTarget.style.top = '0';
                      e.currentTarget.style.left = '0';
                      handleExportToExcel();
                    }}
                  >
                    <i className="ri-file-excel-line" style={{ fontSize: '14px' }}></i>
                    Export Excel
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Exclusion Notice */}
        <div style={{
          backgroundColor: '#e7f3ff',
          border: '1px solid #b3d9ff',
          borderRadius: '6px',
          padding: '12px 16px',
          marginTop: '20px',
          marginBottom: '10px'
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            color: '#0066cc',
            fontSize: '14px',
            fontWeight: '500'
          }}>
            <i className="ri-information-line" style={{ fontSize: '16px' }}></i>
            <span>Expert/Bulk records have already been excluded from the data table</span>
          </div>
        </div>

        {/* Data Table Section */}
        <div className="row">
          <div className="col-sm-12">
            <div style={{ 
              border: '1px solid #dee2e6',
              borderRadius: '8px',
              overflow: 'hidden'
            }}>
              {loading ? (
                <div style={{ textAlign: 'center', padding: '40px' }}>
                  <i className="ri-loader-4-line" style={{ 
                    fontSize: '24px', 
                    animation: 'spin 1s linear infinite',
                    color: '#30ea03'
                  }}></i>
                  <p style={{ marginTop: '10px', color: '#666' }}>Loading data...</p>
                </div>
              ) : tableData.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '40px' }}>
                  <i className="ri-database-2-line" style={{ fontSize: '48px', color: '#ccc' }}></i>
                  <p style={{ marginTop: '10px', color: '#666' }}>No data available</p>
                </div>
              ) : (
                <>
                <div style={{ 
                  backgroundColor: '#fff', 
                  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
                    overflowX: 'auto'
                }}>
                  <table className="table table-striped table-bordered" style={{
                    backgroundColor: '#fff',
                    color: '#212529',
                    border: 'none',
                    margin: 0,
                    width: '100%',
                      minWidth: '3000px' // Ensure minimum width for all 37 columns
                  }}>
                  <thead style={{ 
                    backgroundColor: '#2d2d2d',
                    position: 'sticky',
                    top: 0,
                    zIndex: 10
                  }}>
                    <tr>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '80px' }}>CM Code</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '120px' }}>CM Description</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '80px' }}>SKU Code</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '150px' }}>SKU Description</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '120px' }}>Purchased Quantity</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '100px' }}>Reference SKU</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '140px' }}>SKU Reference Check</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '140px' }}>Formulation Reference</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '100px' }}>Material Type</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '140px' }}>Components Reference</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '120px' }}>Component Code</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '150px' }}>Component Description</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '150px' }}>Component Validity From</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '150px' }}>Component Validity To</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '150px' }}>Component Material Group</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '120px' }}>Component Quantity</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '180px' }}>Component Unit of Measure</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '140px' }}>Component Base Quantity</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '200px' }}>Component Base Unit of Measure</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '120px' }}>Component %w/w</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '80px' }}>Evidence</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '180px' }}>Component Packaging Type</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '180px' }}>Component Packaging Material</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '100px' }}>Helper Column</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '140px' }}>Component Unit Weight</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '140px' }}>Weight Unit Measure</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '300px' }}>% Mechanical Post-Consumer Recycled Content(inc Chemical)</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '280px' }}>% Mechanical Post-Industrial Recycled Content</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '180px' }}>% Chemical Recycled Content</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '100px' }}>% Bio Sourced</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '280px' }}>Material Structure-multimaterial only(with % wt)</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '180px' }}>Component Packaging Colour</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '180px' }}>Component Packaging Level</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '140px' }}>Component Dimensions</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '200px' }}>Packaging Specification Evidence</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '220px' }}>Evidence of Recycled or Bio Source</th>
                      <th style={{ backgroundColor: '#2d2d2d', color: '#ffffff', border: '1px solid #444', padding: '12px 8px', fontSize: '13px', fontWeight: '100', textAlign: 'left', whiteSpace: 'nowrap', minWidth: '120px' }}>Last Update Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tableData.length > 0 ? (
                      tableData.map((row, index) => (
                        <tr key={index} style={{ 
                          backgroundColor: index % 2 === 0 ? '#ffffff' : '#f8f9fa',
                          borderBottom: '1px solid #dee2e6'
                        }}>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.cm_code}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.cm_description}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.sku_code}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.sku_description}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.purchased_quantity}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.reference_sku}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.sku_reference_check}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.formulation_reference}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.material_type}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.components_reference}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_code}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_description}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_validity_from}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_validity_to}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_material_group}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_quantity}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_unit_of_measure}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_base_quantity}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_base_unit_of_measure}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_percent_w_w}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.evidence}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_packaging_type}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_packaging_material}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.helper_column}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_unit_weight}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.weight_unit_measure}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.percent_mechanical_pcr_content}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.percent_mechanical_pir_content}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.percent_chemical_recycled_content}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.percent_bio_sourced}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.material_structure_multimaterial}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_packaging_colour}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_packaging_level}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.component_dimensions}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.packaging_specification_evidence}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.evidence_of_recycled_or_bio_source}</td>
                          <td style={{ color: '#212529', border: '1px solid #dee2e6', padding: '12px 8px', fontSize: '13px', textAlign: 'left' }}>{row.last_update_date}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td 
                          colSpan={37} 
                          style={{ 
                            textAlign: 'center', 
                            padding: '40px 20px',
                            color: '#6c757d',
                            fontSize: '16px',
                            fontWeight: '500',
                            backgroundColor: '#f8f9fa',
                            border: '1px solid #dee2e6'
                          }}
                        >
                          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
                            <div style={{ fontSize: '24px' }}>📊</div>
                            <div>No data found matching the selected filters</div>
                            <div style={{ fontSize: '14px', color: '#868e96' }}>
                              Try adjusting your filter criteria and click "Apply Filters"
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
                  </div>

                  {/* Professional Pagination - Outside scrollable container */}
              <div style={{
                    backgroundColor: '#f8f9fa',
                    padding: '16px 20px',
                    borderTop: '1px solid #dee2e6',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}>
                    <div style={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      gap: '16px',
                      fontSize: '13px',
                      color: '#6c757d'
                    }}>
                      <span>Showing 1 to {tableData.length} of {tableData.length} entries</span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span>Show:</span>
                        <select
                          style={{
                            padding: '4px 8px',
                            border: '1px solid #ced4da',
                            borderRadius: '4px',
                            fontSize: '13px',
                            backgroundColor: '#fff'
                          }}
                        >
                          <option value="10">10</option>
                          <option value="25">25</option>
                          <option value="50">50</option>
                          <option value="100">100</option>
                        </select>
                        <span>entries</span>
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                      <button
                        style={{
                          backgroundColor: '#6c757d',
                          color: '#fff',
                          border: 'none',
                          borderRadius: '4px',
                          padding: '6px 12px',
                          fontSize: '12px',
                          cursor: 'not-allowed',
                          opacity: 0.5
                        }}
                        disabled
                      >
                        Previous
                      </button>
                      <button
                        style={{
                          backgroundColor: '#30ea03',
                          color: '#000',
                          border: 'none',
                          borderRadius: '4px',
                          padding: '6px 12px',
                          fontSize: '12px',
                          cursor: 'pointer',
                          fontWeight: '600'
                        }}
                      >
                        1
                      </button>
                      <button
                        style={{
                          backgroundColor: '#6c757d',
                          color: '#fff',
                          border: 'none',
                          borderRadius: '4px',
                          padding: '6px 12px',
                          fontSize: '12px',
                          cursor: 'not-allowed',
                          opacity: 0.5
                        }}
                        disabled
                      >
                        Next
                      </button>
              </div>
            </div>
                </>
        )}
            </div>
          </div>
        </div>

      </div>
  
    </Layout>
  );
};

export default GaiaPage;
