const db = require('../config/db.config');

/**
 * Get comprehensive audit log data without filters (returns all data)
 */
const getAuditLog = async (request, reply) => {
  try {
    const query = `
      SELECT
        s.period,
        s.cm_code,
        s.sku_code,
        c.component_code,
        json_agg(
          json_build_object(
            'sdp_skudetails_auditlog', s,
            'sdp_sku_component_mapping_details_auditlog', scm,
            'sdp_component_details_auditlog', c
          )
        ) AS audit_logs
      FROM public.sdp_skudetails_auditlog s
      LEFT JOIN public.sdp_sku_component_mapping_details_auditlog scm
        ON s.cm_code = scm.cm_code AND s.sku_code = scm.sku_code
      LEFT JOIN public.sdp_component_details_auditlog c
        ON scm.cm_code = c.cm_code AND scm.sku_code = c.sku_code AND scm.component_code = c.component_code
      GROUP BY s.period, s.cm_code, s.sku_code, c.component_code
      ORDER BY s.period, s.cm_code, s.sku_code, c.component_code;
    `;

    const { rows: records } = await db.query(query);

    // Log the raw records for debugging
    console.log('Query result:', JSON.stringify(records, null, 2));

    // Flatten all audit_logs arrays into a single array of objects
    const allAuditLogs = records.flatMap(r => r.audit_logs || []);

    reply.send({
      success: true,
      message: 'Audit logs fetched successfully',
      data: {
        records: allAuditLogs,
        pagination: {
          total: allAuditLogs.length,
          limit: allAuditLogs.length,
          offset: 0,
          has_more: false,
          current_page: 1,
          total_pages: 1
        },
        filters_applied: {},
        query_summary: {
          total_records: allAuditLogs.length,
          returned_records: allAuditLogs.length,
          query_executed_at: new Date().toISOString()
        }
      }
    });
  } catch (err) {
    console.error('Error fetching audit logs:', err);
    reply.code(500).send({
      success: false,
      message: 'Internal server error',
      error: err.message
    });
  }
};


module.exports = {
  getAuditLog
};
