const pool = require('../config/db.config');

/**
 * Fetch all CM codes with region information
 */
// async function getAllCMCodes() {
//   const result = await pool.query(`
//     SELECT 
//       c.id, 
//       c.cm_code, 
//       c.cm_description, 
//       c.created_at, 
//       c.updated_at, 
//       c.company_name, 
//       c.signoff_by, 
//       c.signoff_date, 
//       c.signoff_status, 
//       c.document_url, 
//       c.periods, 
//       c.is_active,
//       c.region_id,
//       c.srm,
//       c.signatory,
//       c.user_id,
//       r.name as region_name,
//       -- SRM User Details
//       srm_user.id as srm_user_id,
//       srm_user.username as srm_name,
//       srm_user.email as srm_email,
//       srm_user.role as srm_role,
//       srm_user.is_active as srm_is_active,
//       -- Signatory User Details  
//       signatory_user.id as signatory_user_id,
//       signatory_user.username as signatory_name,
//       signatory_user.email as signatory_email,
//       signatory_user.role as signatory_role,
//       signatory_user.is_active as signatory_is_active,
//       -- Additional User Details (user_id)
//       additional_user.id as additional_user_id,
//       additional_user.username as additional_user_name,
//       additional_user.email as additional_user_email,
//       additional_user.role as additional_user_role,
//       additional_user.is_active as additional_user_is_active,
//       -- SPOC Details (from sdp_contractor_spocs)
//       spoc_user.id as spoc_user_id,
//       spoc_user.username as spoc_name,
//       spoc_user.email as spoc_email,
//       spoc_user.role as spoc_role,
//       spoc_user.is_active as spoc_is_active
//     FROM sdp_contractors c
//     LEFT JOIN sdp_region r ON c.region_id = r.id
//     LEFT JOIN sdp_users srm_user ON c.srm = srm_user.id
//     LEFT JOIN sdp_users signatory_user ON c.signatory = signatory_user.id
//     LEFT JOIN sdp_users additional_user ON c.user_id = additional_user.id
//     LEFT JOIN sdp_contractor_spocs cs ON c.id = cs.contractor_id
//     LEFT JOIN sdp_users spoc_user ON cs.user_id = spoc_user.id
//     ORDER BY id DESC
//   `);
//   return result.rows;
// }

async function getAllCMCodes() {
  const result = await pool.query(`
SELECT
  c.id, 
  c.cm_code, 
  c.cm_description, 
  c.created_at, 
  c.updated_at, 
  c.company_name, 
  c.signoff_by, 
  c.signoff_date, 
  c.signoff_status, 
  c.document_url, 
  c.periods, 
  c.is_active,
  c.region_id,
  c.srm,
  c.signatory,
  c.user_id,
  r.name as region_name,
  -- SRM User Details
  srm_user.id as srm_user_id,
  srm_user.username as srm_name,
  srm_user.email as srm_email,
  srm_user.role as srm_role,
  srm_user.is_active as srm_is_active,
  -- Signatory User Details  
  signatory_user.id as signatory_user_id,
  signatory_user.username as signatory_name,
  signatory_user.email as signatory_email,
  signatory_user.role as signatory_role,
  signatory_user.is_active as signatory_is_active,
  -- Additional User Details (user_id)
  additional_user.id as additional_user_id,
  additional_user.username as additional_user_name,
  additional_user.email as additional_user_email,
  additional_user.role as additional_user_role,
  additional_user.is_active as additional_user_is_active,
-- Aggregated SPOC Details
string_agg(spoc_user.username, ', ') as spoc_names,
string_agg(spoc_user.email, ', ') as spoc_emails,
string_agg(spoc_user.role::text, ', ') as spoc_roles,
string_agg(spoc_user.id::text, ', ') as spoc_user_ids

FROM sdp_contractors c
LEFT JOIN sdp_region r ON c.region_id = r.id
LEFT JOIN sdp_users srm_user ON c.srm = srm_user.id
LEFT JOIN sdp_users signatory_user ON c.signatory = signatory_user.id
LEFT JOIN sdp_users additional_user ON c.user_id = additional_user.id
LEFT JOIN sdp_contractor_spocs cs ON c.id = cs.contractor_id
LEFT JOIN sdp_users spoc_user ON cs.user_id = spoc_user.id
GROUP BY 
  c.id, r.name,
  srm_user.id, srm_user.username, srm_user.email, srm_user.role, srm_user.is_active,
  signatory_user.id, signatory_user.username, signatory_user.email, signatory_user.role, signatory_user.is_active,
  additional_user.id, additional_user.username, additional_user.email, additional_user.role, additional_user.is_active
ORDER BY c.id DESC;

  `);
  return result.rows;
}
/**
 * Fetch CM code by cm_code with region information
 */
async function getCMCodeByCode(cm_code) {
  const result = await pool.query(`
    SELECT 
      c.id, 
      c.cm_code, 
      c.cm_description, 
      c.created_at, 
      c.updated_at, 
      c.company_name, 
      c.signoff_by, 
      c.signoff_date, 
      c.signoff_status, 
      c.document_url, 
      c.periods, 
      c.is_active,
      c.region_id,
      c.srm,
      c.signatory,
      c.user_id,
      r.name as region_name,
      -- SRM User Details
      srm_user.id as srm_user_id,
      srm_user.username as srm_name,
      srm_user.email as srm_email,
      srm_user.role as srm_role,
      srm_user.is_active as srm_is_active,
      -- Signatory User Details  
      signatory_user.id as signatory_user_id,
      signatory_user.username as signatory_name,
      signatory_user.email as signatory_email,
      signatory_user.role as signatory_role,
      signatory_user.is_active as signatory_is_active,
      -- Additional User Details (user_id)
      additional_user.id as additional_user_id,
      additional_user.username as additional_user_name,
      additional_user.email as additional_user_email,
      additional_user.role as additional_user_role,
      additional_user.is_active as additional_user_is_active,
      -- SPOC Details (from sdp_contractor_spocs)
      spoc_user.id as spoc_user_id,
      spoc_user.username as spoc_name,
      spoc_user.email as spoc_email,
      spoc_user.role as spoc_role,
      spoc_user.is_active as spoc_is_active
    FROM sdp_contractors c
    LEFT JOIN sdp_region r ON c.region_id = r.id
    LEFT JOIN sdp_users srm_user ON c.srm = srm_user.id
    LEFT JOIN sdp_users signatory_user ON c.signatory = signatory_user.id
    LEFT JOIN sdp_users additional_user ON c.user_id = additional_user.id
    LEFT JOIN sdp_contractor_spocs cs ON c.id = cs.contractor_id
    LEFT JOIN sdp_users spoc_user ON cs.user_id = spoc_user.id
    WHERE c.cm_code = $1
  `, [cm_code]);
  return result.rows;
}

/**
 * Toggle is_active status for a CM code by id
 */
async function toggleCMCodeActiveStatus(id) {
  // First get the current status
  const currentResult = await pool.query('SELECT is_active FROM sdp_contractors WHERE id = $1', [id]);

  if (currentResult.rows.length === 0) {
    return null; // Record not found
  }

  const currentStatus = currentResult.rows[0].is_active;
  const newStatus = !currentStatus; // Toggle the status

  // Update with the new status
  const updateResult = await pool.query(`
    UPDATE sdp_contractors 
    SET is_active = $1, updated_at = CURRENT_TIMESTAMP
    WHERE id = $2 
    RETURNING id, cm_code, cm_description, created_at, updated_at, company_name, signoff_by, signoff_date, signoff_status, document_url, periods, is_active, region_id
  `, [newStatus, id]);

  return updateResult.rows[0];
}

module.exports = { getAllCMCodes, getCMCodeByCode, toggleCMCodeActiveStatus }; 