const { 
  streamPdfController, 
  pdfStreamHealthController 
} = require('../controllers/controller.streamPdf');

const bearerTokenMiddleware = require('../middleware/middleware.bearer');

/**
 * PDF Streaming Routes
 * Handles PDF streaming from Azure Blob Storage
 */

async function streamPdfRoutes(fastify, options) {
  
  // Stream PDF from Azure Blob Storage - GET /api/stream-pdf
  fastify.get('/api/stream-pdf', {
    preHandler: bearerTokenMiddleware,
    schema: {
      response: {
        200: {
          type: 'string',
          description: 'PDF file content as binary stream'
        },
        400: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            error: { type: 'string' },
            details: { type: 'string' }
          }
        },
        401: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            error: { type: 'string' }
          }
        },
        404: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            error: { type: 'string' },
            container: { type: 'string' },
            blob: { type: 'string' }
          }
        },
        500: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            error: { type: 'string' },
            details: { type: 'string' }
          }
        }
      }
    }
  }, streamPdfController);
  
  // Health check for PDF streaming service - GET /api/stream-pdf/health
  fastify.get('/api/stream-pdf/health', {
    schema: {
      response: {
        200: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            status: { type: 'string' },
            azure: {
              type: 'object',
              properties: {
                configured: { type: 'boolean' },
                account: { type: 'string' },
                allowedContainers: { 
                  type: 'array',
                  items: { type: 'string' }
                }
              }
            }
          }
        },
        503: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            status: { type: 'string' },
            error: { type: 'string' }
          }
        }
      }
    }
  }, pdfStreamHealthController);
}

module.exports = streamPdfRoutes;