const pool = require('../config/db.config');

/**
 * Helper function to ensure all required fields are present
 */
function prepareAuditLogData(data) {
  return {
    id: data.id || null,
    sku_code: data.sku_code || null,
    formulation_reference: data.formulation_reference || null,
    material_type_id: data.material_type_id || null,
    components_reference: data.components_reference || null,
    component_code: data.component_code || null,
    component_description: data.component_description || null,
    component_valid_from: data.component_valid_from || null,
    component_valid_to: data.component_valid_to || null,
    component_material_group: data.component_material_group || null,
    component_quantity: data.component_quantity || null,
    component_uom_id: data.component_uom_id || null,
    component_base_quantity: data.component_base_quantity || null,
    component_base_uom_id: data.component_base_uom_id || null,
    percent_w_w: data.percent_w_w || null,
    evidence: data.evidence || null,
    component_packaging_type_id: data.component_packaging_type_id || null,
    component_packaging_material: data.component_packaging_material || null,
    helper_column: data.helper_column || null,
    component_unit_weight: data.component_unit_weight || null,
    weight_unit_measure_id: data.weight_unit_measure_id || null,
    percent_mechanical_pcr_content: data.percent_mechanical_pcr_content || null,
    percent_mechanical_pir_content: data.percent_mechanical_pir_content || null,
    percent_chemical_recycled_content: data.percent_chemical_recycled_content || null,
    percent_bio_sourced: data.percent_bio_sourced || null,
    material_structure_multimaterials: data.material_structure_multimaterials || null,
    component_packaging_color_opacity: data.component_packaging_color_opacity || null,
    component_packaging_level_id: data.component_packaging_level_id || null,
    component_dimensions: data.component_dimensions || null,
    packaging_specification_evidence: data.packaging_specification_evidence || null,
    evidence_of_recycled_or_bio_source: data.evidence_of_recycled_or_bio_source || null,
    last_update_date: data.last_update_date || new Date(),
    category_entry_id: data.category_entry_id || null,
    data_verification_entry_id: data.data_verification_entry_id || null,
    user_id: data.user_id || null,
    signed_off_by: data.signed_off_by || null,
    signed_off_date: data.signed_off_date || null,
    mandatory_fields_completion_status: data.mandatory_fields_completion_status || null,
    evidence_provided: data.evidence_provided || null,
    document_status: data.document_status || null,
    is_active: data.is_active !== undefined ? data.is_active : true,
    created_by: data.created_by || null,
    created_date: data.created_date || new Date(),
    year: data.year || null,
    component_unit_weight_id: data.component_unit_weight_id || null,
    cm_code: data.cm_code || null,
    periods: data.periods || null,
    component_id: data.component_id || null,
    version: data.version || null,
    componentvaliditydatefrom: data.componentvaliditydatefrom || null,
    componentvaliditydateto: data.componentvaliditydateto || null
  };
}

/**
 * Insert a new component details audit log record
 */
async function insertComponentAuditLog(data) {
  // Prepare the data with all required fields
  const auditData = prepareAuditLogData(data);
  const query = `
    INSERT INTO sdp_component_details_auditlog (
      component_id, sku_code, formulation_reference, material_type_id, components_reference, 
      component_code, component_description, component_valid_from, component_valid_to, 
      component_material_group, component_quantity, component_uom_id, component_base_quantity, 
      component_base_uom_id, percent_w_w, evidence, component_packaging_type_id, 
      component_packaging_material, helper_column, component_unit_weight, weight_unit_measure_id, 
      percent_mechanical_pcr_content, percent_mechanical_pir_content, percent_chemical_recycled_content, 
      percent_bio_sourced, material_structure_multimaterials, component_packaging_color_opacity, 
      component_packaging_level_id, component_dimensions, packaging_specification_evidence, 
      evidence_of_recycled_or_bio_source, last_update_date, category_entry_id, 
      data_verification_entry_id, user_id, signed_off_by, signed_off_date
    ) VALUES (
      $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20,
      $21, $22, $23, $24, $25, $26, $27, $28, $29, $30, $31, $32, $33, $34, $35, $36, $37
    ) RETURNING *
  `;

  const values = [
    auditData.component_id, // component_id
    auditData.sku_code, // sku_code
    auditData.formulation_reference, // formulation_reference
    auditData.material_type_id, // material_type_id
    auditData.components_reference, // components_reference
    auditData.component_code, // component_code
    auditData.component_description, // component_description
    auditData.component_valid_from, // component_valid_from
    auditData.component_valid_to, // component_valid_to
    auditData.component_material_group, // component_material_group
    auditData.component_quantity, // component_quantity
    auditData.component_uom_id, // component_uom_id
    auditData.component_base_quantity, // component_base_quantity
    auditData.component_base_uom_id, // component_base_uom_id
    auditData.percent_w_w, // percent_w_w
    auditData.evidence, // evidence
    auditData.component_packaging_type_id, // component_packaging_type_id
    auditData.component_packaging_material, // component_packaging_material
    auditData.helper_column, // helper_column
    auditData.component_unit_weight, // component_unit_weight
    auditData.weight_unit_measure_id, // weight_unit_measure_id
    auditData.percent_mechanical_pcr_content, // percent_mechanical_pcr_content
    auditData.percent_mechanical_pir_content, // percent_mechanical_pir_content
    auditData.percent_chemical_recycled_content, // percent_chemical_recycled_content
    auditData.percent_bio_sourced, // percent_bio_sourced
    auditData.material_structure_multimaterials, // material_structure_multimaterials
    auditData.component_packaging_color_opacity, // component_packaging_color_opacity
    auditData.component_packaging_level_id, // component_packaging_level_id
    auditData.component_dimensions, // component_dimensions
    auditData.packaging_specification_evidence, // packaging_specification_evidence
    auditData.evidence_of_recycled_or_bio_source, // evidence_of_recycled_or_bio_source
    auditData.last_update_date, // last_update_date
    auditData.category_entry_id, // category_entry_id
    auditData.data_verification_entry_id, // data_verification_entry_id
    auditData.user_id, // user_id
    auditData.signed_off_by, // signed_off_by
    auditData.signed_off_date // signed_off_date
  ];

  const result = await pool.query(query, values);
  return result.rows[0];
}

module.exports = { insertComponentAuditLog }; 