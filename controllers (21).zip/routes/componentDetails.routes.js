const { updateComponentDetailsController } = require('../controllers/controller.componentDetails');
const bearerTokenMiddleware = require('../middleware/middleware.bearer');

module.exports = async function (fastify, options) {
  // POST /update-component-detail/:mapping_id
  // Updates or replaces component details with FormData support (New Enhanced API)
  fastify.post('/api/component-details/:mapping_id', {
    schema: {
      consumes: ['multipart/form-data']
    },
    preHandler: [bearerTokenMiddleware, async (request, reply) => {
      // Ensure multipart is properly configured for EIP platforms
      if (!request.isMultipart()) {
        return reply.code(400).send({
          success: false,
          message: 'Request must be multipart/form-data',
          error: 'INVALID_CONTENT_TYPE',
          expectedContentType: 'multipart/form-data; boundary=----WebKitFormBoundary...'
        });
      }
      
      // Log boundary information for debugging
      const contentType = request.headers['content-type'] || '';
      const boundaryMatch = contentType.match(/boundary=([^;]+)/);
      const boundary = boundaryMatch ? boundaryMatch[1] : null;
      
      console.log(`🔍 EIP Platform Debug - Content-Type: ${contentType}`);
      console.log(`🔍 EIP Platform Debug - Boundary: ${boundary || 'MISSING'}`);
      
      if (!boundary) {
        return reply.code(400).send({
          success: false,
          message: 'Missing boundary parameter. Required for EIP platform compatibility.',
          error: 'MISSING_BOUNDARY',
          help: 'Ensure your client sends: Content-Type: multipart/form-data; boundary=----WebKitFormBoundary...'
        });
      }
    }]
  }, updateComponentDetailsController);
};
