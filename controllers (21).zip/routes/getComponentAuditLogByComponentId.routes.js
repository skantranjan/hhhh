const { 
  getComponentAuditLogByComponentIdHandler
} = require('../controllers/controller.getComponentAuditLogByComponentId');
const bearerTokenMiddleware = require('../middleware/middleware.bearer');

/**
 * Routes for component audit log by component_id from both tables
 */
async function routes(fastify, options) {
  // GET component audit log by component_id with JOIN from both tables - Protected route
  fastify.get('/api/component-audit-logs/:componentId', {
    preHandler: bearerTokenMiddleware,
    schema: {
      params: {
        type: 'object',
        required: ['componentId'],
        properties: {
          componentId: {
            type: 'string',
            description: 'Component ID to fetch audit log for with JOIN from both tables'
          }
        }
      },
      response: {
        200: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            data: { type: 'array' },
            summary: {
              type: 'object',
              properties: {
                total_records: { type: 'number' },
                mapping_table_records: { type: 'number' },
                details_table_records: { type: 'number' },
                component_code: { type: 'string' }
              }
            },
            tables: {
              type: 'object',
              properties: {
                mapping: { type: 'array' },
                details: { type: 'array' }
              }
            }
          }
        },
        400: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' }
          }
        },
        404: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            data: { type: 'array' }
          }
        },
        500: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            error: { type: 'string' }
          }
        }
      }
    }
  }, getComponentAuditLogByComponentIdHandler);
}

module.exports = routes; 