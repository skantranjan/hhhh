import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import LandingPage from '../pages/LandingPage';
import CMLandingPage from '../pages/CMLandingPage';
import SRMLandingPage from '../pages/SRMLandingPage';

const RoleBasedRouter: React.FC = () => {
  const { user, isAuthenticated } = useAuth();

  // If not authenticated, don't render anything (AutoSSO will handle authentication)
  if (!isAuthenticated || !user) {
    return null;
  }

  // Route based on user role
  const userRole = user.role;
  
  // Console logging for debugging
  console.log('🔍 RoleBasedRouter: User object:', user);
  console.log('🔍 RoleBasedRouter: User role:', userRole);
  console.log('🔍 RoleBasedRouter: Role type:', typeof userRole);
  console.log('🔍 RoleBasedRouter: Is authenticated:', isAuthenticated);

  switch (userRole) {
    case 1:
    case '1':
      console.log('🔍 RoleBasedRouter: Rendering Admin Landing Page');
      return <LandingPage />;
    
    case 2:
    case '2':
      console.log('🔍 RoleBasedRouter: Rendering CM Landing Page');
      return <CMLandingPage />;
    
    case 3:
    case '3':
      console.log('🔍 RoleBasedRouter: Rendering SRM Landing Page');
      return <SRMLandingPage />;
    
    default:
      console.error('🔍 RoleBasedRouter: Unknown user role:', userRole);
      alert(`Unknown user role: ${userRole}\n\nExpected roles: 1 (Admin), 2 (CM), 3 (SRM)`);
      return null;
  }
};

export default RoleBasedRouter;
