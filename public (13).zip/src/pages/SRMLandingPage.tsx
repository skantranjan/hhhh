import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useSSO } from '../hooks/useSSO';

import '../assets/landing/css/styles.css';
import '../assets/landing/css/new-hero.css';
import '../assets/landing/css/remix-icon.css';
import logoImage from '../assets/landing/images/logo.png';
import landingImage from '../assets/landing/images/Landing.png';

const SRMLandingPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { handleSSOLogin, handleSSOLogout } = useSSO();

  const handleNavigation = (path: string) => {
    console.log('🔍 SRM Card clicked:', path);
    
    if (path === 'cm-dashboard') {
      // User is already authenticated, redirect to SRM dashboard
      const userRole = user?.role;
      if (userRole === '3' || userRole === 3) {
        console.log('🔍 Navigating to SRM dashboard...');
        navigate('/srm/srm-dashboard');
      }
    }
  };

  const handleLogout = async () => {
    try {
      console.log('🔍 Logging out...');
      await handleSSOLogout();
      logout();
      navigate('/landing');
    } catch (error) {
      console.error('❌ Logout error:', error);
      // Force logout even if SSO logout fails
      logout();
      navigate('/landing');
    }
  };

  return (
    <div className="landing-page">
      {/* Top Navigation */}
      <div className="top-nav flex">
        <img 
          src={logoImage} 
          alt="Haleon Logo" 
          className="logoImage"
        />
        <ul className="flex">
          <li><a onClick={() => navigate('/landing')} style={{ cursor: 'pointer' }}><i className="ri-home-5-line"></i> Home </a></li>
          <li><a onClick={handleLogout} style={{ cursor: 'pointer', color: '#ff6b6b' }}><i className="ri-logout-box-line"></i> Logout </a></li>
        </ul>
      </div>

      {/* Main Content */}
      <div className="LandingPage">
        <div className="main">
          <div className="main-inner">
            <h2>Welcome to</h2>
            <h1>SRM Sustainability Data Portal</h1>
            <p>
              The SRM Sustainability Data Portal provides you with access to 
              supplier relationship management tools and sustainability data tracking. 
              Monitor supplier performance and track their environmental impact 
              through our comprehensive platform.
            </p>
            
            <div className="homeButtons flex">
              <a onClick={() => handleNavigation('cm-dashboard')} style={{ cursor: 'pointer' }}>
                <div>
                  <span><i className="ri-file-chart-fill"></i></span>
                </div>
                <span>3 PM Dashboard</span>
              </a>
            </div>
            
            <div className="clearfix"></div>
          </div>

          <div className="RightImage">
            <img src={landingImage} alt="Landing" />
            <div className="Quote">
              <i className="ri-double-quotes-l"></i>
              Embrace the journey of growth, for every step forward is a step towards your dreams
              <i className="ri-double-quotes-r"></i>
              <div className="clearfix"></div>
            </div>
          </div>
        </div>
      </div>

      <footer></footer>
    </div>
  );
};

export default SRMLandingPage;
