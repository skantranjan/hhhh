import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useSSO } from '../hooks/useSSO';

const Header: React.FC = () => {
  const navigate = useNavigate();
  const { logout, user, isAdmin, isCMUser, isSRMUser } = useAuth();
  const { handleCompleteLogout } = useSSO();
  const [showUserMenu, setShowUserMenu] = useState(false);

  const handleHomeClick = () => {
    navigate('/landing');
  };

  const handleLogout = async () => {
    try {
      console.log('🔐 Starting complete logout process...');
      
      // First clear local authentication state
      await logout();
      
      // Then logout from Microsoft SSO
      await handleCompleteLogout();
      
      // Note: handleCompleteLogout will handle the redirect to landing page
      
    } catch (error) {
      console.error('❌ Logout error:', error);
      // Even if there's an error, redirect to landing page
      navigate('/landing');
    }
  };

  // Get user role display name
  const getUserRoleDisplay = () => {
    if (isAdmin) return 'Administrator';
    if (isCMUser) return 'CM User';
    if (isSRMUser) return 'SRM User';
    return 'User';
  };

  // Get user role color
  const getUserRoleColor = () => {
    if (isAdmin) return '#dc3545'; // Red for Admin
    if (isCMUser) return '#0d6efd'; // Blue for CM
    if (isSRMUser) return '#198754'; // Green for SRM
    return '#6c757d'; // Gray for default
  };

  return (
    <div className="top-nav flex">
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
      <img src="https://sustainability-data-portal.eip.dev.haleon.com/ui/images/logo.png" alt="Haleon Logo" className="logoImage" data-themekey="#" />
      <h2>Sustainability Data Portal</h2>
      </div>
      <ul className="flex" style={{ alignItems: 'center', height: '100%' }}>
        <li style={{ display: 'flex', alignItems: 'center', height: '100%', padding: '0 14px' }}><a onClick={handleHomeClick} style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', height: '100%', fontSize: '13px', color: '#fff' }}><i className="ri-home-5-line" style={{ marginRight: '3px', fontSize: '14px' }}></i> Home </a></li>
        {user && (
          <li style={{ position: 'relative', display: 'flex', alignItems: 'center', height: '100%', padding: '0 14px' }}>
            {/* User Profile Dropdown */}
            <div
              onClick={() => setShowUserMenu(!showUserMenu)}
              style={{
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '8px 12px',
                borderRadius: '6px',
                backgroundColor: showUserMenu ? '#f8f9fa' : '#ffffff',
                transition: 'background-color 0.2s ease',
                border: '1px solid #dee2e6',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                height: '40px'
              }}
              onMouseEnter={(e) => {
                if (!showUserMenu) {
                  e.currentTarget.style.backgroundColor = '#f8f9fa';
                }
              }}
              onMouseLeave={(e) => {
                if (!showUserMenu) {
                  e.currentTarget.style.backgroundColor = 'transparent';
                }
              }}
            >
              {/* User Avatar */}
              <div
                style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  backgroundColor: getUserRoleColor(),
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#fff',
                  fontWeight: 'bold',
                  fontSize: '14px'
                }}
              >
                {user.username?.charAt(0).toUpperCase() || 'U'}
              </div>
              
              {/* User Info */}
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                <span style={{ 
                  fontSize: '14px', 
                  fontWeight: '600', 
                  color: '#333',
                  lineHeight: '1.2'
                }}>
                  {user.username}
                </span>
                <span style={{ 
                  fontSize: '12px', 
                  color: getUserRoleColor(),
                  fontWeight: '500',
                  lineHeight: '1.2'
                }}>
                  {getUserRoleDisplay()}
                </span>
              </div>
              
              {/* Dropdown Arrow */}
              <i 
                className={`ri-arrow-down-s-line`} 
                style={{ 
                  fontSize: '16px', 
                  color: '#333',
                  transform: showUserMenu ? 'rotate(180deg)' : 'rotate(0deg)',
                  transition: 'transform 0.2s ease'
                }}
              />
            </div>

            {/* Dropdown Menu */}
            {showUserMenu && (
              <div
                style={{
                  position: 'absolute',
                  top: '100%',
                  right: '0',
                  backgroundColor: '#fff',
                  border: '1px solid #dee2e6',
                  borderRadius: '8px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                  minWidth: '200px',
                  zIndex: 1000,
                  marginTop: '4px'
                }}
              >
                {/* User Info Header */}
                <div style={{
                  padding: '16px',
                  borderBottom: '1px solid #dee2e6',
                  backgroundColor: '#f8f9fa'
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div
                      style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '50%',
                        backgroundColor: getUserRoleColor(),
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#fff',
                        fontWeight: 'bold',
                        fontSize: '16px'
                      }}
                    >
                      {user.username?.charAt(0).toUpperCase() || 'U'}
                    </div>
                    <div>
                      <div style={{ 
                        fontSize: '16px', 
                        fontWeight: '600', 
                        color: '#333',
                        marginBottom: '2px'
                      }}>
                        {user.username}
                      </div>
                      <div style={{ 
                        fontSize: '13px', 
                        color: getUserRoleColor(),
                        fontWeight: '500'
                      }}>
                        {getUserRoleDisplay()}
                      </div>
                      {user.email && (
                        <div style={{ 
                          fontSize: '12px', 
                          color: '#666',
                          marginTop: '2px'
                        }}>
                          {user.email}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Menu Items */}
                <div style={{ padding: '8px 0' }}>
                  {/* Logout Button */}
                  <div
                    onClick={handleLogout}
                    style={{
                      padding: '12px 16px',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px',
                      color: '#dc3545',
                      fontSize: '14px',
                      fontWeight: '500',
                      transition: 'background-color 0.2s ease'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#fff5f5';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = 'transparent';
                    }}
                  >
                    <i className="ri-logout-box-r-line" style={{ fontSize: '16px' }} />
                    <span>Logout</span>
                  </div>
                </div>
              </div>
            )}
          </li>
        )}
      </ul>

      {/* Click outside to close dropdown */}
      {showUserMenu && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            zIndex: 999
          }}
          onClick={() => setShowUserMenu(false)}
        />
      )}
    </div>
  );
};

export default Header; 