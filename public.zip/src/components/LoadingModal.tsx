import React from 'react';
import './LoadingModal.css';

interface LoadingModalProps {
  isVisible: boolean;
  message?: string;
}

const LoadingModal: React.FC<LoadingModalProps> = ({ 
  isVisible, 
  message = "Authenticating... Please wait" 
}) => {
  if (!isVisible) return null;

  return (
    <div className="loading-modal-overlay">
      <div className="loading-modal">
        <div className="loading-spinner">
          <div className="spinner"></div>
        </div>
        <div className="loading-message">
          {message}
        </div>
        <div className="loading-subtitle">
          Verifying your access to the Sustainability Data Portal
        </div>
      </div>
    </div>
  );
};

export default LoadingModal;

