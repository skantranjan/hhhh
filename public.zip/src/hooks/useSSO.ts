import { useMsal } from '@azure/msal-react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { loginRequest } from '../config/msalConfig';
import { useTokenService } from '../utils/tokenService';
import { useApiWithTokenRefresh } from './useApiWithTokenRefresh';

export const useSSO = () => {
  const { instance } = useMsal();
  const { login } = useAuth();
  const navigate = useNavigate();
  const { isTokenExpiring, getFreshToken } = useTokenService();
  const { apiPostWithRefresh } = useApiWithTokenRefresh();

  // Process authentication response (shared by popup and silent auth)
  const processAuthenticationResponse = async (response: any) => {
    if (response.account) {
      // Get user info from Microsoft Graph
      const graphResponse = await instance.acquireTokenSilent({
        ...loginRequest,
        account: response.account
      });

      if (graphResponse.accessToken) {
        // Call Microsoft Graph to get user details
        const userInfo = await fetch('https://graph.microsoft.com/v1.0/me', {
          headers: {
            'Authorization': `Bearer ${graphResponse.accessToken}`,
            'Content-Type': 'application/json'
          }
        });

        if (userInfo.ok) {
          const userData = await userInfo.json();
          const email = userData.mail || userData.userPrincipalName;
          
          if (email) {
            console.log('🔐 SSO Login successful, validating with API:', { email, userData });
            
            // Log SSO tokens
            console.log('🎫 SSO Tokens Generated:');
            console.log('Account Info:', response.account);
            
            // Validate user with your API (with token refresh handling)
            try {
              const apiResponse = await apiPostWithRefresh(
                '/user', 
                { email }, 
                'application/json', 
                response.accessToken
              );
              
              if (apiResponse.success) {
                const userDataFromAPI = apiResponse.data;
                console.log('User validated with API:', userDataFromAPI);
                
                // Store user data in AuthContext
                login(userDataFromAPI);
                
                // Route based on user role and intended destination
                const userRole = userDataFromAPI.role;
                
                // Store user role for role change detection
                localStorage.setItem('lastKnownRole', userRole.toString());
                const intendedDestination = localStorage.getItem('intendedDestination');
                
                console.log('User role:', userRole, 'Intended destination:', intendedDestination);
                
                // Clear the intended destination
                localStorage.removeItem('intendedDestination');
                
                if (intendedDestination === 'audit-log') {
                  // Audit Log Report card was clicked - go directly to audit log page
                  console.log('Redirecting to audit log page');
                  navigate('/audit-log');
                } else if (intendedDestination === 'cm-dashboard') {
                  // 3 PM Dashboard card was clicked - redirect to role-based landing page
                  console.log('Redirecting to role-based landing page for cm-dashboard');
                  navigate('/landing');
                } else if (intendedDestination === 'cm-sku-details') {
                  // SKU/Component Details card was clicked - redirect to role-based landing page
                  console.log('Redirecting to role-based landing page for cm-sku-details');
                  navigate('/landing');
                } else {
                  // No specific destination, redirect to role-based landing page
                  console.log('Redirecting to role-based landing page (no specific destination)');
                  navigate('/landing');
                }
                
                // Return success after successful authentication and navigation
                return {
                  success: true,
                  message: 'SSO authentication successful'
                };
                
              } else {
                // User exists in Azure AD but not in your database
                throw new Error('ACCESS_DENIED');
              }
              
            } catch (apiError: any) {
              if (apiError.message === 'ACCESS_DENIED') {
                throw new Error('ACCESS_DENIED');
              } else {
                throw new Error(`API validation failed: ${apiError.message}`);
              }
            }
            
          } else {
            throw new Error('Email not found in user profile');
          }
        } else {
          throw new Error('Failed to fetch user info from Microsoft Graph');
        }
      } else {
        throw new Error('Failed to acquire access token');
      }
    } else {
      throw new Error('No account information received');
    }
  };

  const handleSSOLogin = async () => {
    try {
      // Try silent authentication first
      const accounts = instance.getAllAccounts();
      if (accounts.length > 0) {
        try {
          const silentResponse = await instance.acquireTokenSilent({
            ...loginRequest,
            account: accounts[0]
          });
          
          if (silentResponse.accessToken) {
            console.log('✅ Silent authentication successful');
            return await processAuthenticationResponse(silentResponse);
          }
        } catch (silentError) {
          console.log('ℹ️ Silent authentication failed, trying popup...');
        }
      }
      
      // Fallback to popup if silent fails
      const response = await instance.loginPopup(loginRequest);
      return await processAuthenticationResponse(response);
    } catch (error: any) {
      console.error('SSO Login error:', error);
      
      if (error.message === 'ACCESS_DENIED') {
        return {
          success: false,
          error: 'ACCESS_DENIED',
          message: 'Access Denied: Your account is not authorized to access this application. Please contact your administrator or use a different account.'
        };
      }
      
      return {
        success: false,
        error: 'SSO_FAILED',
        message: error.message || 'SSO authentication failed'
      };
    }
  };

  const handleSSOLogout = async () => {
    try {
      console.log('🔐 Starting SSO logout...');
      
      // Clear local authentication state first
      // This will be handled by your AuthContext logout
      
      // Perform MSAL logout
      await instance.logoutPopup();
      console.log('✅ SSO logout successful');
      
      // Redirect to landing page after successful logout
      navigate('/landing');
      
    } catch (error) {
      console.error('❌ SSO logout error:', error);
      // Even if MSAL logout fails, redirect to landing page
      navigate('/landing');
    }
  };

  // Comprehensive logout function that handles both local and SSO logout
  const handleCompleteLogout = async () => {
    try {
      console.log('🔐 Starting complete logout process...');
      
      // First, clear local authentication state
      // This will be handled by your AuthContext logout
      
      // Then perform MSAL logout
      await instance.logoutPopup();
      console.log('✅ SSO logout successful');
      
      // Redirect to landing page after successful logout
      navigate('/landing');
      
    } catch (error) {
      console.error('❌ SSO logout error:', error);
      // Even if MSAL logout fails, redirect to landing page
      navigate('/landing');
    }
  };

  // Function to get fresh token for API calls
  const getFreshTokenForAPI = async (): Promise<string | null> => {
    try {
      const accounts = instance.getAllAccounts();
      if (accounts.length > 0) {
        const freshToken = await getFreshToken(accounts[0]);
        return freshToken;
      }
      return null;
    } catch (error) {
      console.error('Failed to get fresh token:', error);
      return null;
    }
  };

  return {
    handleSSOLogin,
    handleSSOLogout,
    handleCompleteLogout,
    getFreshTokenForAPI
  };
};
