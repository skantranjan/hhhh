import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams, useNavigate, useLocation } from 'react-router-dom';
import Layout from '../components/Layout';
import MultiSelect from '../components/MultiSelect';
import ConfirmModal from '../components/ConfirmModal';
import { apiGet } from '../utils/api';

// Master Data Response Interface
interface MasterDataResponse {
  success: boolean;
  message: string;
  data: {
    periods?: Array<{id: number, period: string, is_active: boolean}>;
    regions?: Array<{id: number, name: string}>;
    material_types?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    component_uoms?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    packaging_materials?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    packaging_levels?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    component_base_uoms?: Array<{id: number, item_name: string, item_order: number, is_active: boolean}>;
    total_count?: {
      periods: number;
      regions: number;
      material_types: number;
      component_uoms: number;
      packaging_materials: number;
      packaging_levels: number;
      component_base_uoms: number;
    };
  };
}

const GaiaPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();
  
  // Data will be loaded from API instead of passed from AdminCmSkuDetail page
  const [cmCode, setCmCode] = useState<string>('');
  const [cmDescription, setCmDescription] = useState<string>('');
  const [selectedYears, setSelectedYears] = useState<string[]>([]);
  const [selectedRows, setSelectedRows] = useState<number[]>([]);
  const [years, setYears] = useState<Array<{id: string, period: string}>>([]);
  const [tableData, setTableData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showNoDataModal, setShowNoDataModal] = useState(false);
  const [showMaxSelectionModal, setShowMaxSelectionModal] = useState(false);
  const lastFilteredDataRef = useRef<string>('');
  const [selectedMaterialType, setSelectedMaterialType] = useState<string>('1');
  const [materialTypes, setMaterialTypes] = useState<Array<{id: number, item_name: string}>>([]);
  const [isFilterApplied, setIsFilterApplied] = useState<boolean>(true);
  
  // New filter states for additional master data
  const [selectedRegion, setSelectedRegion] = useState<string>('');
  const [regions, setRegions] = useState<Array<{id: number, name: string}>>([]);
  const [selectedComponentUom, setSelectedComponentUom] = useState<string>('');
  const [componentUoms, setComponentUoms] = useState<Array<{id: number, item_name: string}>>([]);
  const [selectedPackagingMaterial, setSelectedPackagingMaterial] = useState<string>('');
  const [packagingMaterials, setPackagingMaterials] = useState<Array<{id: number, item_name: string}>>([]);
  const [selectedPackagingLevel, setSelectedPackagingLevel] = useState<string>('');
  const [packagingLevels, setPackagingLevels] = useState<Array<{id: number, item_name: string}>>([]);
  const [selectedComponentBaseUom, setSelectedComponentBaseUom] = useState<string>('');
  const [componentBaseUoms, setComponentBaseUoms] = useState<Array<{id: number, item_name: string}>>([]);
  
  // Master data state
  const [masterData, setMasterData] = useState<MasterDataResponse['data'] | null>(null);
  const [periods, setPeriods] = useState<Array<{id: number, period: string, is_active: boolean}>>([]);
  const [currentPeriod, setCurrentPeriod] = useState<string>('');
  const [selectedPeriod, setSelectedPeriod] = useState<string>('');
  const [selectedComponentType, setSelectedComponentType] = useState<string>('');
  const [selectedComponentPackagingTypes, setSelectedComponentPackagingTypes] = useState<string[]>([]);
  const [excludeInternal, setExcludeInternal] = useState<boolean>(true);
  const [appliedExcludeInternal, setAppliedExcludeInternal] = useState<boolean>(true);
  const [appliedPeriod, setAppliedPeriod] = useState<string>('');
  const [appliedComponentType, setAppliedComponentType] = useState<string>('');
  const [appliedComponentPackagingTypes, setAppliedComponentPackagingTypes] = useState<string[]>([]);
  const [componentPackagingTypes, setComponentPackagingTypes] = useState<Array<{id: number, item_name: string, item_name_new?: string}>>([]);
  const [hasLoadedInitialData, setHasLoadedInitialData] = useState<boolean>(false);

  // Load initial data on component mount
  useEffect(() => {
    loadInitialData();
  }, []);

  // Load component data when CMO code and applied filters are ready (only once)
  useEffect(() => {
    console.log('🔍 useEffect triggered with:', { cmCode, appliedPeriod, appliedComponentType, hasLoadedInitialData });
    if (cmCode && appliedPeriod && appliedComponentType && !hasLoadedInitialData) {
      console.log('🔄 CMO code and filters ready, loading component data...');
      setHasLoadedInitialData(true);
      loadComponentData();
    }
  }, [cmCode, appliedPeriod, appliedComponentType, hasLoadedInitialData]);

  // Load master data
  const loadMasterData = async () => {
    try {
      console.log('🔄 Loading master data...');
      console.log('📡 API Endpoint: /masterdata');
      
      const response = await apiGet('/masterdata');
      
      console.log('📥 Master data response received:', response);
      
      if (response.success && response.data) {
        console.log('✅ Master data loaded successfully');
        console.log('📊 Master data structure:', {
          periods: response.data.periods?.length || 0,
          material_types: response.data.material_types?.length || 0,
          regions: response.data.regions?.length || 0,
          component_uoms: response.data.component_uoms?.length || 0,
          packaging_materials: response.data.packaging_materials?.length || 0,
          packaging_levels: response.data.packaging_levels?.length || 0,
          component_base_uoms: response.data.component_base_uoms?.length || 0
        });
        
        setMasterData(response.data);
        setPeriods(response.data.periods || []);
        setMaterialTypes(response.data.material_types || []);
        setRegions(response.data.regions || []);
        setComponentUoms(response.data.component_uoms || []);
        setPackagingMaterials(response.data.packaging_materials || []);
        setPackagingLevels(response.data.packaging_levels || []);
        setComponentBaseUoms(response.data.component_base_uoms || []);
        
        // Set component packaging types from master data
        console.log('🔍 Checking for component_packaging_type in response:', {
          hasComponentPackagingType: !!response.data.component_packaging_type,
          componentPackagingTypeLength: response.data.component_packaging_type?.length || 0,
          sampleData: response.data.component_packaging_type?.[0] || null
        });
        
        if (response.data.component_packaging_type) {
          const packagingTypes = response.data.component_packaging_type.map((type: any) => ({
            id: type.id,
            item_name: type.item_name,
            item_name_new: type.item_name_new
          }));
          setComponentPackagingTypes(packagingTypes);
          console.log('📦 Component packaging types loaded from master data:', packagingTypes.length);
          console.log('📦 Sample packaging type:', packagingTypes[0]);
        } else {
          console.warn('⚠️ No component_packaging_type found in master data response');
        }
        
        
        // Set current period to the highest active period
        const activePeriods = (response.data.periods || []).filter((p: any) => p.is_active);
        let periodId = '';
        if (activePeriods.length > 0) {
          const highestPeriod = activePeriods.reduce((max: any, current: any) => 
            current.id > max.id ? current : max
          );
          periodId = highestPeriod.id.toString();
          setCurrentPeriod(periodId);
          setSelectedPeriod(periodId);
          console.log('📅 Current period set to:', highestPeriod.period, '(ID:', highestPeriod.id, ')');
        } else {
          console.warn('⚠️ No active periods found in master data');
        }
        
        // Set default component type from master data (first material type)
        let defaultComponentType = '';
        if (response.data.material_types && response.data.material_types.length > 0) {
          defaultComponentType = response.data.material_types[0].item_name;
          setSelectedComponentType(defaultComponentType);
          console.log('🏷️ Default component type set to:', defaultComponentType);
        }
        
        // Initialize applied filter states with current values
        setAppliedPeriod(periodId);
        setAppliedComponentType(defaultComponentType);
        setAppliedComponentPackagingTypes([]);
        setAppliedExcludeInternal(true);
        
        // Clear any previous errors
        setError(null);
      } else {
        console.error('❌ Failed to load master data:', response.message || 'Unknown error');
        setError(`Failed to load master data: ${response.message || 'Unknown error'}`);
      }
    } catch (error: any) {
      console.error('❌ Error loading master data:', error);
      console.error('🔍 Error details:', {
        message: error.message,
        stack: error.stack,
        name: error.name
      });
      setError(`Error loading master data: ${error.message || 'Network or server error'}`);
    }
  };

  // Load initial data
  const loadInitialData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Load master data first
      await loadMasterData();
      
      // Get parameters from URL
      const cmCodeParam = searchParams.get('cmCode');
      const cmDescriptionParam = searchParams.get('cmDescription');
      
      if (cmCodeParam) {
        setCmCode(cmCodeParam);
      }
      
      if (cmDescriptionParam) {
        setCmDescription(cmDescriptionParam);
      }

      // Get data from location state if available
      const locationState = location.state;
      if (locationState?.skuData) {
        setTableData(locationState.skuData);
      }
      
    } catch (error) {
      console.error('Error loading initial data:', error);
      setError('Error loading initial data');
    } finally {
      setLoading(false);
    }
  };

  // Helper function to extract unique SKUs from API data
  const extractUniqueSkus = (apiData: any[]) => {
    console.log('🔍 extractUniqueSkus called with data:', apiData);
    
    const uniqueSkus = new Map();
    
    if (!apiData || !Array.isArray(apiData)) {
      console.warn('⚠️ apiData is not an array or is undefined');
      return [];
    }
    
    apiData.forEach((item: any, index: number) => {
      const skuCode = item['SKU Code'] || item.sku_code;
      const skuDescription = item['SKU Description'] || item.sku_description || skuCode;
      
      if (skuCode && !uniqueSkus.has(skuCode)) {
        uniqueSkus.set(skuCode, {
          id: uniqueSkus.size + 1,
          sku_code: skuCode,
          sku_description: skuDescription
        });
        console.log(`✅ Added SKU: ${skuCode} - ${skuDescription}`);
      }
    });
    
    const result = Array.from(uniqueSkus.values());
    console.log(`📦 Extracted ${result.length} unique SKUs`);
    return result;
  };


  // Load component data based on current filters
  const loadComponentData = async () => {
    if (!cmCode) {
      console.log('⚠️ No CMO code available, skipping component data load');
      return;
    }

    try {
      console.log('🔄 Loading component data for CMO:', cmCode);
      console.log('📊 Current filters:', {
        period: appliedPeriod || currentPeriod,
        componentType: appliedComponentType,
        excludeInternal: appliedExcludeInternal,
        packagingTypes: appliedComponentPackagingTypes,
        region: selectedRegion,
        componentUom: selectedComponentUom,
        packagingMaterial: selectedPackagingMaterial,
        packagingLevel: selectedPackagingLevel,
        componentBaseUom: selectedComponentBaseUom
      });
      
      // Load ALL data without any filters for client-side filtering
      const params = new URLSearchParams({
        cm_code: cmCode,
        period_id: appliedPeriod || currentPeriod
        // Remove all other filters - we'll filter on the client side
      });
      
      console.log('🔍 API Parameters being sent (ALL DATA):', {
        cm_code: cmCode,
        period_id: appliedPeriod || currentPeriod,
        note: 'Loading all data for client-side filtering'
      });


      // All filtering will be done client-side, no additional API parameters needed

      // Use the filterdata-generatepdf API endpoint
      const response = await apiGet(`/components/filterdata-generatepdf?${params.toString()}`);
      
      console.log('📥 Component data response received:', response);
      
      if (response.success) {
        // Transform the API response
        const transformedData = transformApiResponse(response.data);
        
        console.log('🔄 Transformed data:', {
          originalCount: response.data?.length || 0,
          transformedCount: transformedData.length,
          sampleRecord: transformedData[0] || null
        });
        
        // Update table data with filtered results
        setTableData(transformedData);
        
        // Keep packaging types from masterdata; do not overwrite with component response
        // This ensures the filter always shows the full master list bound to item_name_new
        // setComponentPackagingTypes(extractUniqueComponentPackagingTypes(response.data));
        // console.log('📦 Unique packaging types found:', uniquePackagingTypes.length);
        
        
        console.log('✅ Component data loaded successfully:', transformedData.length, 'records');
        
        // Clear any previous errors
        setError(null);
      } else {
        console.error('❌ Failed to load component data:', response.message);
        setError(`Failed to load component data: ${response.message || 'Unknown error'}`);
      }
    } catch (error: any) {
      console.error('❌ Error loading component data:', error);
      console.error('🔍 Error details:', {
        message: error.message,
        stack: error.stack,
        name: error.name
      });
      setError(`Error loading component data: ${error.message || 'Network or server error'}`);
    }
  };

  // Transform API response to table format
  const transformApiResponse = (data: any) => {
    if (!data || !Array.isArray(data)) return [];
    
    return data.map((item: any, index: number) => ({
      id: index,
      sku_code: item.sku_code || '',
      sku_description: item.sku_description || '',
      component_code: item.component_code || '',
      component_description: item.component_description || '',
      component_valid_from: item.component_valid_from || '',
      component_valid_to: item.component_valid_to || '',
      component_quantity: item.component_quantity || '',
      component_uom_id: item.component_uom_id || '',
      component_base_quantity: item.component_base_quantity || '',
      component_base_uom_id: item.component_base_uom_id || '',
      component_packaging_type_id: item.component_packaging_type_id || '',
      component_packaging_material: item.component_packaging_material || '',
      component_unit_weight: item.component_unit_weight || '',
      weight_unit_measure_id: item.weight_unit_measure_id || '',
      percent_mechanical_pcr_content: item.percent_mechanical_pcr_content || '',
      components_reference: item.components_reference || '',
      component_material_group: item.component_material_group || '',
      percent_w_w: item.percent_w_w || '',
      percent_mechanical_pir_content: item.percent_mechanical_pir_content || '',
      percent_chemical_recycled_content: item.percent_chemical_recycled_content || '',
      percent_bio_sourced: item.percent_bio_sourced || '',
      material_structure_multimaterials: item.material_structure_multimaterials || '',
      component_packaging_level_id: item.component_packaging_level_id || '',
      component_dimensions: item.component_dimensions || ''
    }));
  };


  // Extract unique component packaging types from API response
  const extractUniqueComponentPackagingTypes = (data: any) => {
    if (!data || !Array.isArray(data)) return [];
    
    const uniqueTypes = new Map();
    data.forEach((item: any) => {
      if (item.component_packaging_type_id) {
        uniqueTypes.set(item.component_packaging_type_id, {
          id: uniqueTypes.size + 1,
          item_name: item.component_packaging_type_id
        });
      }
    });
    
    return Array.from(uniqueTypes.values());
  };

  // Handle apply filters button click
  const handleApplyFilters = () => {
    console.log('🔍 Applying filters...');
    console.log('📊 Current table data length:', tableData.length);
    console.log('📅 Selected Period:', selectedPeriod);
    console.log('🏷️ Selected Component Type:', selectedComponentType);
    console.log('📦 Selected Component Packaging Types:', selectedComponentPackagingTypes);
    console.log('🚫 Exclude Internal:', excludeInternal);
    
    // Update all applied filter states
    setAppliedPeriod(selectedPeriod || currentPeriod);
    setAppliedComponentType(selectedComponentType);
    setAppliedComponentPackagingTypes([...selectedComponentPackagingTypes]);
    setAppliedExcludeInternal(excludeInternal);
    
    // Reset selected rows
    setSelectedRows([]);
    
    // Apply client-side filtering
    applyClientSideFilters();
    
    console.log('✅ Filters applied successfully');
  };

  // Apply client-side filtering to the data
  const applyClientSideFilters = () => {
    console.log('🔍 Applying client-side filters...');
    console.log('📊 Original table data count:', tableData.length);
    
    let filteredData = [...tableData];
    
    // Apply Component Type filter
    if (appliedComponentType) {
      filteredData = filteredData.filter(row => {
        // Assuming the data has a material_type field that matches the selected component type
        return row.material_type === appliedComponentType || 
               row.component_material_type === appliedComponentType ||
               row.component_type === appliedComponentType;
      });
      console.log('🏷️ After Component Type filter:', filteredData.length);
    }
    
    // Apply Component Packaging Types filter
    if (appliedComponentPackagingTypes.length > 0) {
      filteredData = filteredData.filter(row => {
        // Check if the row's packaging type matches any of the selected types
        return appliedComponentPackagingTypes.some(selectedType => 
          row.component_packaging_type === selectedType ||
          row.component_packaging_type_id === selectedType ||
          row.packaging_type === selectedType
        );
      });
      console.log('📦 After Packaging Types filter:', filteredData.length);
    }
    
    // Apply Exclude Internal filter
    if (appliedExcludeInternal) {
      filteredData = filteredData.filter(row => {
        // Exclude rows that are marked as internal
        return !row.is_internal && 
               !row.internal_component &&
               row.component_type !== 'Internal';
      });
      console.log('🚫 After Exclude Internal filter:', filteredData.length);
    }
    
    // Apply Region filter
    if (selectedRegion) {
      filteredData = filteredData.filter(row => 
        row.region_id === selectedRegion || 
        row.region === selectedRegion
      );
      console.log('🌍 After Region filter:', filteredData.length);
    }
    
    // Apply Component UOM filter
    if (selectedComponentUom) {
      filteredData = filteredData.filter(row => 
        row.component_uom_id === selectedComponentUom || 
        row.component_uom === selectedComponentUom
      );
      console.log('📏 After Component UOM filter:', filteredData.length);
    }
    
    // Apply Packaging Material filter
    if (selectedPackagingMaterial) {
      filteredData = filteredData.filter(row => 
        row.packaging_material_id === selectedPackagingMaterial || 
        row.component_packaging_material === selectedPackagingMaterial
      );
      console.log('📦 After Packaging Material filter:', filteredData.length);
    }
    
    // Apply Packaging Level filter
    if (selectedPackagingLevel) {
      filteredData = filteredData.filter(row => 
        row.packaging_level_id === selectedPackagingLevel || 
        row.component_packaging_level === selectedPackagingLevel
      );
      console.log('📊 After Packaging Level filter:', filteredData.length);
    }
    
    // Apply Component Base UOM filter
    if (selectedComponentBaseUom) {
      filteredData = filteredData.filter(row => 
        row.component_base_uom_id === selectedComponentBaseUom || 
        row.component_base_uom === selectedComponentBaseUom
      );
      console.log('⚖️ After Component Base UOM filter:', filteredData.length);
    }
    
    // Update the table data with filtered results
    setTableData(filteredData);
    
    console.log('✅ Client-side filtering completed. Final filtered data count:', filteredData.length);
  };

  // Handle reset filters button click
  const handleResetFilters = () => {
    console.log('Resetting filters...');
    
    // Reset all filter states to default values
    setSelectedPeriod(currentPeriod);
    setSelectedComponentType('');
    setSelectedComponentPackagingTypes([]);
    setExcludeInternal(true);
    
    // Reset applied filter states
    setAppliedPeriod(currentPeriod);
    setAppliedComponentType('');
    setAppliedComponentPackagingTypes([]);
    setAppliedExcludeInternal(true);
    setSelectedRegion('');
    setSelectedComponentUom('');
    setSelectedPackagingMaterial('');
    setSelectedPackagingLevel('');
    setSelectedComponentBaseUom('');
    
    // Reset selected rows
    setSelectedRows([]);
    
    // Apply client-side filtering with reset values (shows all data)
    console.log('🔄 Applying reset filters...');
    applyClientSideFilters();
  };

  // Handle row selection
  const handleRowSelect = (rowId: number) => {
    setSelectedRows(prev => {
      if (prev.includes(rowId)) {
        return prev.filter(id => id !== rowId);
      } else {
        if (prev.length >= 1000) {
          setShowMaxSelectionModal(true);
          return prev;
        }
        return [...prev, rowId];
      }
    });
  };

  // Handle select all rows
  const handleSelectAll = () => {
    if (selectedRows.length === tableData.length) {
      setSelectedRows([]);
    } else {
      if (tableData.length > 1000) {
        setShowMaxSelectionModal(true);
        return;
      }
      setSelectedRows(tableData.map((_, index) => index));
    }
  };

  return (
    <Layout>
      <div className="mainInternalPages">
        <div style={{ marginBottom: 8 }}>
        </div>
        {/* Dashboard Header */}
        <div className="commonTitle" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <div className="icon">
              <i className="ri-global-line"></i>
            </div>
            <h1>GAIA</h1>
          </div>
          <button
            onClick={() => navigate(-1)}
            style={{
              background: '#30ea03',
              color: '#000',
              border: 'none',
              borderRadius: '4px',
              padding: '10px 20px',
              fontWeight: 'bold',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '14px',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
              transition: 'all 0.2s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = '#28c003';
              e.currentTarget.style.transform = 'translateY(-1px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = '#30ea03';
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            <i className="ri-arrow-left-line"></i>
            Back
          </button>
        </div>

        {/* CMO Info Section */}
        <div className="filters CMDetails">
          <div className="row">
            <div className="col-sm-12">
              <ul style={{ display: 'flex', alignItems: 'center', padding: '6px 15px 8px' }}>
                <li><strong>CMO Code: </strong> {cmCode}</li>
                <li> | </li>
                <li><strong>CMO Description: </strong> {cmDescription}</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Professional Error Display Section */}
        {error && (
              <div style={{
            background: 'linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%)',
            border: '1px solid #fecaca',
            borderRadius: '12px',
            padding: '20px 24px',
            marginBottom: '24px',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            boxShadow: '0 2px 12px rgba(239, 68, 68, 0.1)'
          }}>
            <div style={{
              background: '#ef4444',
              borderRadius: '8px',
              padding: '8px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0
            }}>
              <i className="ri-error-warning-line" style={{ fontSize: '18px', color: '#fff' }}></i>
            </div>
            <div>
              <div style={{ 
                fontSize: '14px', 
                fontWeight: '600', 
                color: '#dc2626',
                marginBottom: '4px'
              }}>
                Error Loading Data
              </div>
              <div style={{ 
                fontSize: '14px', 
                color: '#991b1b',
                lineHeight: '1.5'
              }}>
                {error}
              </div>
            </div>
          </div>
        )}

        {/* Professional Filters Section - Reference Design */}
        <div className="row"> 
          <div className="col-sm-12">
            <div className="filters" style={{
              backgroundColor: '#fff',
              borderRadius: '8px',
              padding: '20px',
              marginBottom: '20px',
              border: '1px solid #e9ecef',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)'
            }}>
              {/* Filter Row */}
              <div style={{ 
                display: 'flex', 
                gap: '16px', 
                alignItems: 'end',
                flexWrap: 'wrap',
                marginBottom: '16px'
              }}>
                {/* Period Filter */}
                <div style={{ flex: '1', minWidth: '180px' }}>
                  <div className="fBold" style={{ marginBottom: '4px', fontSize: '13px', fontWeight: '600', color: '#495057' }}>Period</div>
                    <select
                      value={currentPeriod}
                      disabled={true}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        borderRadius: '4px',
                      fontSize: '13px',
                      backgroundColor: '#f8f9fa',
                      border: '1px solid #ced4da',
                        outline: 'none',
                      color: '#6c757d',
                      cursor: 'not-allowed',
                      height: '36px'
                      }}
                    >
                      <option value={currentPeriod}>
                        {periods.find(p => p.id.toString() === currentPeriod)?.period || 'Loading...'}
                      </option>
                    </select>
                  </div>

                {/* Component Type Filter */}
                <div style={{ flex: '1', minWidth: '180px' }}>
                  <div className="fBold" style={{ marginBottom: '4px', fontSize: '13px', fontWeight: '600', color: '#495057' }}>Component Type</div>
                    <select
                      value={selectedComponentType}
                      onChange={(e) => setSelectedComponentType(e.target.value)}
                      style={{
                        width: '100%',
                        padding: '8px 12px',
                        borderRadius: '4px',
                      fontSize: '13px',
                      border: '1px solid #ced4da',
                      outline: 'none',
                      backgroundColor: '#fff',
                      height: '36px'
                      }}
                    >
                      {materialTypes.map(type => (
                        <option key={type.id} value={type.item_name}>
                          {type.item_name}
                        </option>
                      ))}
                    </select>
                  </div>

                {/* Packaging Types Filter */}
                <div style={{ flex: '1', minWidth: '200px' }}>
                  <div className="fBold" style={{ marginBottom: '4px', fontSize: '13px', fontWeight: '600', color: '#495057' }}>Component Packaging Types</div>
                    <MultiSelect
                      options={(() => {
                        const filtered = componentPackagingTypes.filter(type => type.item_name_new);
                        const mapped = filtered.map(type => ({
                          value: type.item_name_new!,
                          label: type.item_name_new!
                        }));
                        console.log('🔍 MultiSelect options debug:', {
                          totalComponentPackagingTypes: componentPackagingTypes.length,
                          filteredCount: filtered.length,
                          mappedCount: mapped.length,
                          sampleOption: mapped[0] || null
                        });
                        return mapped;
                      })()}
                      selectedValues={selectedComponentPackagingTypes}
                      onSelectionChange={setSelectedComponentPackagingTypes}
                      placeholder="Select packaging types..."
                    />
                  </div>


                {/* Exclude Internal Checkbox */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '20px' }}>
                    <input
                      type="checkbox"
                    id="excludeInternal"
                      checked={excludeInternal}
                      onChange={(e) => setExcludeInternal(e.target.checked)}
                    style={{ 
                      width: '16px', 
                      height: '16px',
                      accentColor: '#30ea03'
                    }}
                  />
                  <label 
                    htmlFor="excludeInternal"
                    style={{ 
                      fontSize: '13px', 
                      color: '#495057',
                      fontWeight: '500',
                      cursor: 'pointer'
                    }}
                  >
                    Exclude Internal
                    </label>
                  </div>
              </div>

              {/* Action Buttons Row */}
              <div style={{ 
                display: 'flex', 
                gap: '12px', 
                justifyContent: 'flex-end',
                alignItems: 'center'
              }}>
                  <button
                    onClick={handleApplyFilters}
                    style={{
                      backgroundColor: '#30ea03',
                      color: '#000',
                      border: 'none',
                    borderRadius: '4px',
                    padding: '8px 16px',
                    fontSize: '13px',
                      fontWeight: '600',
                      cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    transition: 'all 0.2s ease',
                    height: '36px'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = '#28c003';
                    e.currentTarget.style.transform = 'translateY(-1px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = '#30ea03';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}
                >
                  <i className="ri-search-line" style={{ fontSize: '14px' }}></i>
                    Apply Filters
                  </button>
                  <button
                    onClick={handleResetFilters}
                    style={{
                    backgroundColor: '#000',
                      color: '#fff',
                      border: 'none',
                    borderRadius: '4px',
                    padding: '8px 16px',
                    fontSize: '13px',
                      fontWeight: '600',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    transition: 'all 0.2s ease',
                    height: '36px'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = '#333';
                    e.currentTarget.style.transform = 'translateY(-1px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = '#000';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}
                >
                  <i className="ri-refresh-line" style={{ fontSize: '14px' }}></i>
                  Reset
                  </button>
                <button
                  onClick={() => {/* TODO: Add export functionality */}}
                  style={{
                    backgroundColor: '#30ea03',
                    color: '#000',
                    border: 'none',
                    borderRadius: '4px',
                    padding: '8px 16px',
                    fontSize: '13px',
                    fontWeight: '600',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    transition: 'all 0.2s ease',
                    height: '36px'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = '#28c003';
                    e.currentTarget.style.transform = 'translateY(-1px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = '#30ea03';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}
                >
                  <i className="ri-file-excel-line" style={{ fontSize: '14px' }}></i>
                  Export to Excel
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Data Table Section */}
        <div className="row">
          <div className="col-sm-12">
            <div className="table-responsive" style={{ 
              overflowX: 'auto',
              maxWidth: '100%',
              border: '1px solid #dee2e6',
              borderRadius: '8px'
            }}>
              {loading ? (
                <div style={{ textAlign: 'center', padding: '40px' }}>
                  <i className="ri-loader-4-line" style={{ 
                    fontSize: '24px', 
                    animation: 'spin 1s linear infinite',
                    color: '#30ea03'
                  }}></i>
                  <p style={{ marginTop: '10px', color: '#666' }}>Loading data...</p>
                </div>
              ) : tableData.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '40px' }}>
                  <i className="ri-database-2-line" style={{ fontSize: '48px', color: '#ccc' }}></i>
                  <p style={{ marginTop: '10px', color: '#666' }}>No data available</p>
                </div>
              ) : (
                <div style={{ 
                  backgroundColor: '#fff', 
                  borderRadius: '8px', 
                  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
                  border: '1px solid #dee2e6'
                }}>
                  <table className="table table-striped table-bordered" style={{
                    backgroundColor: '#fff',
                    color: '#212529',
                    border: 'none',
                    margin: 0,
                    width: '100%',
                    minWidth: '1500px' // Ensure minimum width for all columns
                  }}>
                  <thead style={{ 
                    backgroundColor: '#2d2d2d',
                    position: 'sticky',
                    top: 0,
                    zIndex: 10
                  }}>
                    <tr>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>SKU Code</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>SKU Description</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>Component Code</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>Component Description</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>Component Qty</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>Component UoM</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>Component Packaging Type</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>Component Packaging Material</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>Component Unit Weight</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>Weight Unit of Measure</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>% Mechanical Post-Consumer Recycled Content</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>Component Material Group</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>%w/w</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>% Mechanical Post-Industrial Recycled Content</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>% Chemical Recycled Content</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>% Bio-sourced</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>Component Packaging Level</th>
                      <th style={{ 
                        backgroundColor: '#2d2d2d', 
                        color: '#ffffff', 
                        border: '1px solid #444',
                        padding: '12px 8px',
                        fontSize: '13px',
                        fontWeight: '600',
                        textAlign: 'left'
                      }}>Component Dimensions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tableData.length > 0 ? (
                      tableData.map((row, index) => (
                        <tr key={index} style={{ 
                          backgroundColor: index % 2 === 0 ? '#ffffff' : '#f8f9fa',
                          borderBottom: '1px solid #dee2e6'
                        }}>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.sku_code}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.sku_description}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.component_code}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.component_description}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.component_quantity}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.component_uom_id}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.component_packaging_type_id}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.component_packaging_material}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.component_unit_weight}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.weight_unit_measure_id}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.percent_mechanical_pcr_content}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.component_material_group}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.percent_w_w}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.percent_mechanical_pir_content}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.percent_chemical_recycled_content}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.percent_bio_sourced}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.component_packaging_level_id}</td>
                          <td style={{ 
                            color: '#212529', 
                            border: '1px solid #dee2e6',
                            padding: '12px 8px',
                            fontSize: '13px',
                            textAlign: 'left'
                          }}>{row.component_dimensions}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td 
                          colSpan={17} 
                          style={{ 
                            textAlign: 'center', 
                            padding: '40px 20px',
                            color: '#6c757d',
                            fontSize: '16px',
                            fontWeight: '500',
                            backgroundColor: '#f8f9fa',
                            border: '1px solid #dee2e6'
                          }}
                        >
                          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
                            <div style={{ fontSize: '24px' }}>📊</div>
                            <div>No data found matching the selected filters</div>
                            <div style={{ fontSize: '14px', color: '#868e96' }}>
                              Try adjusting your filter criteria and click "Apply Filters"
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>

                  {/* Professional Pagination */}
              <div style={{
                    backgroundColor: '#f8f9fa',
                    padding: '16px 20px',
                    borderTop: '1px solid #dee2e6',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}>
                    <div style={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      gap: '16px',
                      fontSize: '13px',
                      color: '#6c757d'
                    }}>
                      <span>Showing 1 to {tableData.length} of {tableData.length} entries</span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span>Show:</span>
                        <select
                          style={{
                            padding: '4px 8px',
                            border: '1px solid #ced4da',
                            borderRadius: '4px',
                            fontSize: '13px',
                            backgroundColor: '#fff'
                          }}
                        >
                          <option value="10">10</option>
                          <option value="25">25</option>
                          <option value="50">50</option>
                          <option value="100">100</option>
                        </select>
                        <span>entries</span>
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                      <button
                        style={{
                          backgroundColor: '#6c757d',
                          color: '#fff',
                          border: 'none',
                          borderRadius: '4px',
                          padding: '6px 12px',
                          fontSize: '12px',
                          cursor: 'not-allowed',
                          opacity: 0.5
                        }}
                        disabled
                      >
                        Previous
                      </button>
                      <button
                        style={{
                          backgroundColor: '#30ea03',
                          color: '#000',
                          border: 'none',
                          borderRadius: '4px',
                          padding: '6px 12px',
                          fontSize: '12px',
                          cursor: 'pointer',
                          fontWeight: '600'
                        }}
                      >
                        1
                      </button>
                      <button
                        style={{
                          backgroundColor: '#6c757d',
                          color: '#fff',
                          border: 'none',
                          borderRadius: '4px',
                          padding: '6px 12px',
                          fontSize: '12px',
                          cursor: 'not-allowed',
                          opacity: 0.5
                        }}
                        disabled
                      >
                        Next
                      </button>
              </div>
            </div>
          </div>
        )}
            </div>
          </div>
        </div>

      </div>

      {/* Modals */}
  
    </Layout>
  );
};

export default GaiaPage;
