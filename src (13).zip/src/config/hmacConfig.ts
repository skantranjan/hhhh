// HMAC Authentication Configuration
// Now using environment-specific settings

import { ENV_CONFIG } from './environment';

export const hmacConfig = {
  ID: ENV_CONFIG.HMAC_ID,
  KEY: ENV_CONFIG.HMAC_KEY,
  API_KEY: ENV_CONFIG.HMAC_API_KEY,
  BASE_URL: ENV_CONFIG.API_BASE_URL,
  STATIC_TOKEN: ENV_CONFIG.HMAC_STATIC_TOKEN
};

// Get current configuration
export const getCurrentConfig = () => {
  return hmacConfig;
};

// Constants that don't change across environments
export const FIXED_CONFIG = {
  API_KEY: 'bGMxYSqsNUb6F88L9rTY3OOMCynzZKAF', // This key is fixed and won't change
  ID: 'SustainibilityPortal' // This ID is also fixed
};
