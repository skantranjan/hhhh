const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function(app) {
  app.use(
    '/api',
    createProxyMiddleware({
      target: 'https://haleon-api-dev.apigee.net',
      changeOrigin: true,
      pathRewrite: {
        '^/api': '/Sustainibility-portal-channel/v1'
      },
      onProxyReq: (proxyReq, req, res) => {
        // Add CORS headers
        proxyReq.setHeader('Origin', 'https://sustainability-data-portal.eip.dev.haleon.com');
      },
      onProxyRes: (proxyRes, req, res) => {
        // Add CORS headers to response
        proxyRes.headers['Access-Control-Allow-Origin'] = 'https://sustainability-data-portal.eip.dev.haleon.com';
        proxyRes.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS';
        proxyRes.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, x-apikey, requestid, timestamp, Origin';
      }
    })
  );
};
