import React from 'react';
import './ErrorModal.css';

interface ErrorModalProps {
  isVisible: boolean;
  message?: string;
  onClose: () => void;
}

const ErrorModal: React.FC<ErrorModalProps> = ({ 
  isVisible, 
  message = "You are not authorized to access this application",
  onClose 
}) => {
  if (!isVisible) return null;

  return (
    <div className="error-modal-overlay">
      <div className="error-modal">
        <div className="error-icon">
          <i className="ri-error-warning-line"></i>
        </div>
        <div className="error-title">
          Access Denied
        </div>
        <div className="error-message">
          {message}
        </div>
        <div className="error-subtitle">
          Please contact your administrator if you believe this is an error.
        </div>
        <button 
          className="error-close-btn"
          onClick={onClose}
        >
          Close
        </button>
      </div>
    </div>
  );
};

export default ErrorModal;

