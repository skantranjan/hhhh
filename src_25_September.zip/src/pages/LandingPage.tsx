import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useSSO } from '../hooks/useSSO';


import '../assets/landing/css/styles.css';
import '../assets/landing/css/new-hero.css';
import '../assets/landing/css/remix-icon.css';
import logoImage from '../assets/landing/images/logo.png';
import landingImage from '../assets/landing/images/Landing.png';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAdmin, isCMUser, isSRMUser, isAuthenticated, logout } = useAuth();
  const { handleSSOLogin, handleSSOLogout } = useSSO();

  // Handle intended destination from card clicks
  useEffect(() => {
    if (isAuthenticated && user) {
      // Check if there's an intended destination stored (from card click)
      const intendedDestination = localStorage.getItem('intendedDestination');
      console.log('🔍 Retrieved intendedDestination from localStorage:', intendedDestination);
      
      if (intendedDestination) {
        console.log('🔍 Found intended destination:', intendedDestination);
        
        // Handle specific destinations
        if (intendedDestination === 'audit-log') {
          console.log('🔍 Navigating to audit-log page...');
          localStorage.removeItem('intendedDestination'); // Clear after use
          navigate('/audit-log');
          return; // Exit early to prevent further execution
        }
        
        // Handle other destinations based on user role
        const userRole = user.role;
        console.log('🔍 User role:', userRole);
        if (intendedDestination === 'cm-dashboard' && (userRole === '1' || userRole === 1)) {
          console.log('🔍 Navigating to admin dashboard...');
          localStorage.removeItem('intendedDestination');
          navigate('/admin/cm-dashboard');
          return; // Exit early to prevent further execution
        }
        
        // Clear the intended destination if not handled
        localStorage.removeItem('intendedDestination');
      }
    }
  }, [isAuthenticated, user, navigate]);

  const handleNavigation = (path: string) => {
    console.log('🔍 Admin Card clicked:', path);
    
    // User is already authenticated, navigate directly based on card clicked
    if (path === 'cm-dashboard') {
      // 3 PM Dashboard card clicked - go to AdminSmDashboard (main admin dashboard)
      console.log('🔍 Navigating to AdminSmDashboard...');
      navigate('/admin/cm-dashboard');
    } else if (path === 'audit-log') {
      // Audit Log Report card clicked - go to AuditLog
      console.log('🔍 Navigating to AuditLog...');
      navigate('/audit-log');
    }
  };

  const handleLogout = async () => {
    try {
      console.log('🔍 Logging out...');
      await handleSSOLogout();
      logout();
      navigate('/landing');
    } catch (error) {
      console.error('❌ Logout error:', error);
      // Force logout even if SSO logout fails
      logout();
      navigate('/landing');
    }
  };

  return (
    <div className="landing-page">
      {/* Top Navigation */}
      <div className="top-nav flex">
        <img 
          src={logoImage} 
          alt="Haleon Logo" 
          className="logoImage"
        />
        <ul className="flex">
          <li><a onClick={() => navigate('/landing')} style={{ cursor: 'pointer' }}><i className="ri-home-5-line"></i> Home </a></li>
          <li><a onClick={handleLogout} style={{ cursor: 'pointer', color: '#ff6b6b' }}><i className="ri-logout-box-line"></i> Logout </a></li>
        </ul>
      </div>

      {/* Main Content */}
      <div className="LandingPage">
        <div className="main">
          <div className="main-inner">
            <h2>Welcome to</h2>
            <h1>Sustainability Data Portal</h1>
            <p>
              The Sustainability Data Portal is a centralized platform designed to collect, 
              manage, and analyze data related to sustainability initiatives. It serves as a  comprehensive resource for organizations to track their environmental impact, 
              social responsibility efforts, and governance practices.
            </p>
            
            <div className="homeButtons flex">
              <a onClick={() => handleNavigation('cm-dashboard')} style={{ cursor: 'pointer' }}>
                <div>
                  <span><i className="ri-file-chart-fill"></i></span>
                </div>
                <span>3 PM Dashboard</span>
              </a>
              
              {/* <a onClick={() => handleNavigation('cm-sku-details')} style={{ cursor: 'pointer' }}>
               <div>
                 <span><i className="ri-file-text-fill"></i></span>
                </div>
                <span>SKU/Component Details</span>
              </a> */}
              
              {/* <a onClick={() => handleNavigation('audit-log')} style={{ cursor: 'pointer' }}>
                <div>
                  <span><i className="ri-file-list-3-fill"></i></span>
                </div>
                <span>Audit Log Report</span>
              </a> */}
            </div>
            


            <div className="clearfix"></div>
          </div>

          <div className="RightImage">
            <img src={landingImage} alt="Landing" />
            <div className="Quote">
              <i className="ri-double-quotes-l"></i>
              Embrace the journey of growth, for every step forward is a step towards your dreams
              <i className="ri-double-quotes-r"></i>
              <div className="clearfix"></div>
            </div>
          </div>
        </div>
      </div>

             

      <footer></footer>
    </div>
  );
};

export default LandingPage;
